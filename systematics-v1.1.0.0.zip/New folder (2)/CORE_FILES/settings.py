"""Persistent user preferences for Systematics TRILLION MIDI maker.

Settings are stored as a small JSON file in the user's home directory so the
application can be moved around freely without carrying state with it.
"""

from __future__ import annotations

import json
import os
from pathlib import Path

SETTINGS_FILE = Path.home() / ".systematics_trillion_midi_maker.json"

DEFAULTS: dict = {
    "multiplier": 65535,
    "compression_preset": 6,
    "fast_mode": False,
    "double_compress": False,
    "remember_input": True,
    "auto_output": True,
    "theme": "dark",          # "dark" or "light"
    "check_updates": True,     # poll the built-in update feed on startup
    "last_input": "",
    "last_output": "",
}


def load(path: Path | str | None = None) -> dict:
    """Load settings, merging them over :data:`DEFAULTS`."""
    target = Path(path) if path is not None else Path(SETTINGS_FILE)
    settings = dict(DEFAULTS)
    try:
        if target.is_file():
            with open(target, "r", encoding="utf-8") as f:
                loaded = json.load(f)
            if isinstance(loaded, dict):
                settings.update(loaded)
    except (OSError, ValueError):
        # A corrupt/unreadable settings file should never block the app.
        pass
    return _coerce(settings)


def save(settings: dict, path: Path | str | None = None) -> None:
    """Persist ``settings`` to disk (best effort)."""
    target = Path(path) if path is not None else Path(SETTINGS_FILE)
    try:
        target.parent.mkdir(parents=True, exist_ok=True)
        with open(target, "w", encoding="utf-8") as f:
            json.dump(_coerce(settings), f, indent=2)
    except OSError:
        pass


def reset(path: Path | str | None = None) -> dict:
    """Return defaults and (optionally) delete the stored file."""
    if path is not None:
        try:
            os.remove(path)
        except OSError:
            pass
    return dict(DEFAULTS)


def _coerce(settings: dict) -> dict:
    """Clamp values into sane ranges so a hand-edited file can't break the UI."""
    out = dict(DEFAULTS)
    out.update(settings)
    out["multiplier"] = max(1, min(65535, int(out.get("multiplier", DEFAULTS["multiplier"]))))
    out["compression_preset"] = max(0, min(9, int(out.get("compression_preset", DEFAULTS["compression_preset"]))))
    for key in ("fast_mode", "double_compress", "remember_input",
                "auto_output", "check_updates"):
        out[key] = bool(out.get(key, DEFAULTS[key]))
    out["theme"] = out.get("theme", DEFAULTS["theme"])
    if out["theme"] not in ("dark", "light"):
        out["theme"] = "dark"
    for key in ("last_input", "last_output"):
        out[key] = str(out.get(key, DEFAULTS[key]))
    return out
