"""MIDI parsing, validation and XZ duplication for Systematics TRILLION MIDI maker.

The idea (taken from the original ``trillion.py`` example, then hardened):

* Accept a MIDI file that contains exactly **one** track of notes.
* Rewrite the header so the track count becomes the chosen multiplier.
* Repeat that single track chunk ``multiplier`` times.
* Store the result inside a single ``.xz`` stream so the (potentially huge)
  uncompressed MIDI takes almost no disk space.

Two write strategies are provided:

* **streamed** (default) — one continuous XZ stream; LZMA sees the repeated
  track and produces the smallest possible file.
* **fast** — the track is compressed once and that one compressed block is
  written repeatedly (concatenated XZ streams). Nearly instant, but larger.
"""

from __future__ import annotations

import io
import lzma
import os
import time
from dataclasses import dataclass

MIN_TRACKS = 1
MAX_TRACKS = 65535  # the MIDI track-count field is an unsigned 16-bit value

MIDI_FORMATS = (0, 1)
CHUNK_HEADER = b"MThd"
CHUNK_TRACK = b"MTrk"


class MidiError(Exception):
    """Raised when the input MIDI is missing, malformed or not single-track."""


class Cancelled(Exception):
    """Raised inside a build when the user cancels the operation."""


@dataclass
class MidiInfo:
    """Everything the engine needs to know about a validated input MIDI."""

    path: str
    format: int
    ntrks: int
    division: bytes          # the 2-byte "division" field from the header
    track_chunks: list       # raw "MTrk" chunks (id + length + data)
    note_count: int          # note-on events (velocity > 0)
    end_of_track: bool       # whether an End-of-Track meta event was seen
    input_size: int          # size of the input file in bytes


@dataclass
class BuildResult:
    """Summary of a finished duplication run."""

    output_path: str
    multiplier: int
    input_size: int
    uncompressed_size: int
    compressed_size: int
    elapsed: float
    note_count: int
    fast_mode: bool
    double_compress: bool = False


# --------------------------------------------------------------------------
# Low level MIDI helpers
# --------------------------------------------------------------------------

def _read_vlq(data: bytes, i: int) -> tuple[int, int]:
    """Read a MIDI variable-length quantity starting at ``i``.

    Returns ``(value, next_index)``.
    """
    value = 0
    n = len(data)
    for _ in range(4):  # MIDI VLQs are at most 4 bytes
        if i >= n:
            raise MidiError("Truncated variable-length value in MIDI track.")
        byte = data[i]
        i += 1
        value = (value << 7) | (byte & 0x7F)
        if not byte & 0x80:
            return value, i
    raise MidiError("Invalid variable-length value in MIDI track.")


def _scan_track(track_data: bytes) -> tuple[int, bool]:
    """Walk a track's events, counting note-ons and checking structure.

    Returns ``(note_count, has_end_of_track)``. Raises :class:`MidiError` for
    structurally broken tracks.
    """
    i = 0
    n = len(track_data)
    running_status: int | None = None
    note_count = 0
    end_of_track = False

    while i < n:
        # Delta time (ignored here, only validated).
        _, i = _read_vlq(track_data, i)
        if i >= n:
            raise MidiError("MIDI track ends in the middle of an event.")

        first = track_data[i]

        if first == 0xFF:  # meta event
            if i + 1 >= n:
                raise MidiError("Truncated MIDI meta event.")
            meta_type = track_data[i + 1]
            i += 2
            length, i = _read_vlq(track_data, i)
            if i + length > n:
                raise MidiError("Truncated MIDI meta event data.")
            if meta_type == 0x2F and length == 0:
                end_of_track = True
            i += length

        elif first in (0xF0, 0xF7):  # SysEx event
            i += 1
            length, i = _read_vlq(track_data, i)
            if i + length > n:
                raise MidiError("Truncated MIDI SysEx event.")
            i += length

        else:
            # Channel (voice) message, possibly using running status.
            if first & 0x80:
                status = first
                running_status = status
                i += 1
            else:
                if running_status is None:
                    raise MidiError("Running status used before any status byte.")
                status = running_status

            high = status & 0xF0
            if high in (0x80, 0x90, 0xA0, 0xB0, 0xE0):  # two data bytes
                if i + 2 > n:
                    raise MidiError("Truncated MIDI channel message.")
                data1 = track_data[i]
                data2 = track_data[i + 1]
                i += 2
                if high == 0x90 and (data2 & 0x7F) > 0:
                    note_count += 1
            elif high in (0xC0, 0xD0):  # one data byte
                if i + 1 > n:
                    raise MidiError("Truncated MIDI channel message.")
                i += 1
            else:
                raise MidiError(f"Invalid MIDI status byte 0x{status:02X}.")

    return note_count, end_of_track


# --------------------------------------------------------------------------
# Parsing / validation
# --------------------------------------------------------------------------

def parse_midi(path: str) -> MidiInfo:
    """Read a MIDI file and return its structure without enforcing track count."""
    if not os.path.isfile(path):
        raise MidiError(f"File not found: {path}")

    with open(path, "rb") as f:
        magic = f.read(4)
        if magic != CHUNK_HEADER:
            raise MidiError("Not a standard MIDI file (missing 'MThd' header).")

        header_len = int.from_bytes(f.read(4), "big")
        if header_len < 6:
            raise MidiError("Invalid MIDI header (length < 6).")
        header = f.read(header_len)
        if len(header) != header_len:
            raise MidiError("Truncated MIDI header.")

        fmt = int.from_bytes(header[0:2], "big")
        ntrks = int.from_bytes(header[2:4], "big")
        division = header[4:6]

        track_chunks: list[bytes] = []
        note_count = 0
        end_of_track = False
        while True:
            chunk_id = f.read(4)
            if chunk_id == b"":
                break
            if chunk_id != CHUNK_TRACK:
                raise MidiError(
                    f"Unexpected chunk {chunk_id!r} in MIDI file (expected {CHUNK_TRACK!r})."
                )
            track_len = int.from_bytes(f.read(4), "big")
            track_data = f.read(track_len)
            if len(track_data) != track_len:
                raise MidiError("Truncated MIDI track data.")
            track_chunks.append(
                CHUNK_TRACK + int.to_bytes(track_len, 4, "big") + track_data
            )
            notes, eot = _scan_track(track_data)
            note_count += notes
            end_of_track = end_of_track or eot

    return MidiInfo(
        path=path,
        format=fmt,
        ntrks=ntrks,
        division=division,
        track_chunks=track_chunks,
        note_count=note_count,
        end_of_track=end_of_track,
        input_size=os.path.getsize(path),
    )


def validate_single_track(path: str) -> MidiInfo:
    """Parse ``path`` and require a well-formed MIDI with exactly one note track."""
    info = parse_midi(path)

    if info.format not in MIDI_FORMATS:
        raise MidiError(f"Unsupported MIDI format {info.format} (expected 0 or 1).")

    actual = max(info.ntrks, len(info.track_chunks))
    if actual != 1:
        raise MidiError(
            f"This file has {actual} tracks. "
            "Systematics TRILLION MIDI maker needs exactly 1 track."
        )

    if info.note_count == 0:
        raise MidiError("The single track contains no note events.")

    return info


# --------------------------------------------------------------------------
# Duplication / compression
# --------------------------------------------------------------------------

def make_header(multiplier: int, division: bytes) -> bytes:
    """Build a format-1 MIDI header with ``multiplier`` tracks."""
    return (
        b"MThd"
        + b"\x00\x00\x00\x06"
        + b"\x00\x01"
        + int.to_bytes(multiplier, 2, "big")
        + division
    )


def human_size(num: int) -> str:
    """Format a byte count for display (e.g. ``12.4 GB``)."""
    value = float(num)
    for unit in ("B", "KB", "MB", "GB", "TB", "PB"):
        if value < 1024.0 or unit == "PB":
            if unit == "B":
                return f"{int(value)} B"
            return f"{value:.1f} {unit}"
        value /= 1024.0
    return f"{value:.1f} PB"  # pragma: no cover


def build_duplicated_xz(
    input_path: str,
    output_path: str,
    multiplier: int,
    preset: int = 6,
    fast: bool = False,
    double_compress: bool = False,
    progress_cb=None,
    progress2_cb=None,
    cancel_event=None,
    info: MidiInfo | None = None,
) -> BuildResult:
    """Duplicate a single-track MIDI ``multiplier`` times into ``output_path``.

    ``progress_cb(done, total)`` reports track progress; ``progress2_cb(done,
    total)`` reports the optional second (.xz.xz) pass in bytes.
    ``cancel_event`` is an optional :class:`threading.Event`.

    ``info`` is an optional already-parsed :class:`MidiInfo` (e.g. the one the
    UI keeps in memory after the file is chosen). When provided the file is
    **not** re-read from disk, so repeated runs skip the slow parse step.
    """
    if not MIN_TRACKS <= multiplier <= MAX_TRACKS:
        raise MidiError(
            f"Multiplier must be between {MIN_TRACKS} and {MAX_TRACKS}, got {multiplier}."
        )
    if not 0 <= preset <= 9:
        raise MidiError(f"Compression preset must be 0-9, got {preset}.")

    if info is None:
        info = validate_single_track(input_path)
    track = info.track_chunks[0]
    header = make_header(multiplier, info.division)

    filters = [{"id": lzma.FILTER_LZMA2, "preset": preset}]
    uncompressed = len(header) + len(track) * multiplier
    started = time.perf_counter()
    step = max(1, multiplier // 1000)  # ~1000 progress callbacks at most

    out_dir = os.path.dirname(os.path.abspath(output_path))
    os.makedirs(out_dir, exist_ok=True)

    def _tick(i: int) -> None:
        if progress_cb is not None and (i % step == 0 or i == multiplier - 1):
            progress_cb(i + 1, multiplier)

    def _check_cancel() -> None:
        if cancel_event is not None and cancel_event.is_set():
            raise Cancelled()

    def _first_pass(out) -> None:
        if fast:
            # Compress each part once, then repeat the compressed blocks.
            # Produces valid concatenated XZ streams.
            header_xz = lzma.compress(header, preset=preset)
            track_xz = lzma.compress(track, preset=preset)
            out.write(header_xz)
            for i in range(multiplier):
                _check_cancel()
                out.write(track_xz)
                _tick(i)
        else:
            # One continuous XZ stream: LZMA exploits the repetition and the
            # result is dramatically smaller than the fast path.
            compressor = lzma.LZMACompressor(
                format=lzma.FORMAT_XZ,
                check=lzma.CHECK_CRC64,
                filters=filters,
            )
            out.write(compressor.compress(header))
            for i in range(multiplier):
                _check_cancel()
                out.write(compressor.compress(track))
                _tick(i)
            out.write(compressor.flush())

    if double_compress:
        # First pass buffers the .xz in memory so we can recompress it.
        stage = io.BytesIO()
        _first_pass(stage)
        stage_bytes = stage.getvalue()
        stage.close()

        # Second pass: compress the .xz stream again into .xz.xz.
        with open(output_path, "wb") as out:
            second = lzma.LZMACompressor(
                format=lzma.FORMAT_XZ,
                check=lzma.CHECK_CRC64,
                filters=filters,
            )
            total = len(stage_bytes)
            chunk = 1 << 20  # 1 MiB at a time keeps memory flat
            done = 0
            for i in range(0, total, chunk):
                _check_cancel()
                piece = stage_bytes[i:i + chunk]
                out.write(second.compress(piece))
                done += len(piece)
                if progress2_cb is not None:
                    progress2_cb(done, total)
            out.write(second.flush())
            if progress2_cb is not None:
                progress2_cb(total, total)
    else:
        with open(output_path, "wb") as out:
            _first_pass(out)

    elapsed = time.perf_counter() - started
    return BuildResult(
        output_path=output_path,
        multiplier=multiplier,
        input_size=info.input_size,
        uncompressed_size=uncompressed,
        compressed_size=os.path.getsize(output_path),
        elapsed=elapsed,
        note_count=info.note_count,
        fast_mode=fast,
        double_compress=double_compress,
    )
