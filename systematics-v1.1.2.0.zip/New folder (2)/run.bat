@echo off
cd /d "%~dp0"
python trillion.py