"""tkinter desktop UI for Systematics TRILLION MIDI maker.

Layout: a sidebar (hamburger header whose label shows the active page, four
navigation items and a footer) plus a main area with a small brand bar, tile
buttons (Start / Stop / Customise / File properties) around a central document
card, and a status line. The style echoes the original H63DNC look but is its
own thing: it supports light and dark themes, a hover glow on the tiles, and
an optional update-feed checker.
"""

from __future__ import annotations

import os
import queue
import subprocess
import sys
import tempfile
import threading
import time
import webbrowser

import tkinter as tk
from tkinter import filedialog, messagebox, ttk

from . import APP_NAME, __version__
from . import icons
from . import midi_engine
from . import news as app_news
from . import settings as app_settings
from . import updater

# Built-in update + news feeds (hosted on GitHub Pages).
UPDATE_FEED_URL = updater.DEFAULT_FEED_URL
NEWS_FEED_URL = app_news.DEFAULT_NEWS_URL


def _console(message: str, end: str = "\n") -> None:
    """Print to the terminal without crashing under ``pythonw`` (no console)."""
    try:
        print(message, end=end, flush=True)
    except Exception:
        pass

# --------------------------------------------------------------------------
# Palettes (dark + light)
# --------------------------------------------------------------------------

PALETTES = {
    "dark": {
        "SIDEBAR": "#2b2b2b",
        "SIDEBAR_HEADER": "#1f1f1f",
        "NAV_ACTIVE": "#333333",
        "MAIN_BG": "#1b1b1b",
        "TILE": "#262626",
        "TILE_HOVER": "#323232",
        "TILE_DISABLED": "#202020",
        "TILE_BORDER": "#3a3a3a",
        "CARD": "#232323",
        "CARD_BORDER": "#343434",
        "ACCENT": "#00AEEF",
        "ACCENT_HOVER": "#2cc2ff",
        "TEXT": "#f2f2f2",
        "TEXT_MUTED": "#8f8f8f",
        "FIELD": "#242424",
        "BUTTON_SECONDARY": "#2b2b2b",
        "BUTTON_SECONDARY_HOVER": "#3a3a3a",
        "ACCENT_ON": "#04121a",
        "NEWS_BG": "#2b2b2b",
    },
    "light": {
        "SIDEBAR": "#e6e6e6",
        "SIDEBAR_HEADER": "#f0f0f0",
        "NAV_ACTIVE": "#d8d8d8",
        "MAIN_BG": "#f2f2f2",
        "TILE": "#ffffff",
        "TILE_HOVER": "#e9e9e9",
        "TILE_DISABLED": "#e2e2e2",
        "TILE_BORDER": "#d1d1d1",
        "CARD": "#ffffff",
        "CARD_BORDER": "#d6d6d6",
        "ACCENT": "#0078d4",
        "ACCENT_HOVER": "#1f95e0",
        "TEXT": "#1c1c1c",
        "TEXT_MUTED": "#6a6a6a",
        "FIELD": "#ffffff",
        "BUTTON_SECONDARY": "#e4e4e4",
        "BUTTON_SECONDARY_HOVER": "#d5d5d5",
        "ACCENT_ON": "#ffffff",
        "NEWS_BG": "#e6e6e6",
    },
}

PALETTE = PALETTES["dark"]  # active palette (module-level so Tile can read it)


def set_palette(name: str) -> None:
    global PALETTE
    PALETTE = PALETTES.get(name, PALETTES["dark"])


def _font(size: int, weight: str = "normal") -> tuple:
    return ("Segoe UI", size, weight)


# --------------------------------------------------------------------------
# Theme (ttk styling)
# --------------------------------------------------------------------------

def apply_theme(root: tk.Tk) -> None:
    style = ttk.Style(root)
    try:
        style.theme_use("clam")
    except tk.TclError:
        pass
    p = PALETTE
    root.configure(bg=p["SIDEBAR"])
    style.configure(".", background=p["MAIN_BG"], foreground=p["TEXT"],
                    fieldbackground=p["FIELD"], bordercolor=p["TILE_BORDER"],
                    lightcolor=p["FIELD"], darkcolor=p["FIELD"],
                    troughcolor=p["FIELD"], selectbackground=p["ACCENT"],
                    focuscolor=p["ACCENT"])
    style.configure("TFrame", background=p["MAIN_BG"])
    style.configure("TLabel", background=p["MAIN_BG"], foreground=p["TEXT"])
    style.configure("TEntry", fieldbackground=p["FIELD"], foreground=p["TEXT"],
                    insertcolor=p["TEXT"], padding=6)
    style.configure("TSpinbox", fieldbackground=p["FIELD"], foreground=p["TEXT"],
                    insertcolor=p["TEXT"], arrowcolor=p["TEXT"], padding=6)
    style.configure("TCombobox", fieldbackground=p["FIELD"], foreground=p["TEXT"],
                    arrowcolor=p["TEXT"], padding=6)
    style.map("TCombobox",
              fieldbackground=[("readonly", p["FIELD"])],
              foreground=[("readonly", p["TEXT"])],
              selectbackground=[("readonly", p["FIELD"])],
              selectforeground=[("readonly", p["TEXT"])])
    style.configure("TCheckbutton", background=p["MAIN_BG"], foreground=p["TEXT"],
                    focuscolor=p["MAIN_BG"])
    style.map("TCheckbutton",
              background=[("active", p["MAIN_BG"])],
              foreground=[("active", p["TEXT"])])
    style.configure("TRadiobutton", background=p["MAIN_BG"], foreground=p["TEXT"],
                    focuscolor=p["MAIN_BG"])
    style.map("TRadiobutton",
              background=[("active", p["MAIN_BG"])],
              foreground=[("active", p["TEXT"])])
    style.configure("TScrollbar", background=p["FIELD"], troughcolor=p["MAIN_BG"],
                    arrowcolor=p["TEXT"], bordercolor=p["MAIN_BG"])
    style.configure("Accent.Horizontal.TProgressbar", troughcolor=p["FIELD"],
                    background=p["ACCENT"], bordercolor=p["FIELD"],
                    lightcolor=p["ACCENT"], darkcolor=p["ACCENT"])


# --------------------------------------------------------------------------
# Tile button (rounded square + icon + caption)
# --------------------------------------------------------------------------

class Tile:
    """A clickable rounded tile with a canvas icon and a caption below it."""

    def __init__(self, parent, text, subtext=None, command=None, size=104,
                 icon_draw=None, image=None):
        p = PALETTE
        self.frame = tk.Frame(parent, bg=p["MAIN_BG"], cursor="hand2")
        self.canvas = tk.Canvas(self.frame, width=size, height=size,
                                bg=p["MAIN_BG"], highlightthickness=0, bd=0)
        self.canvas.pack()
        self.label = tk.Label(self.frame, text=text, bg=p["MAIN_BG"], fg=p["TEXT"],
                              font=_font(10, "bold"))
        self.label.pack(pady=(6, 0))
        self.sub = None
        if subtext is not None:
            self.sub = tk.Label(self.frame, text=subtext, bg=p["MAIN_BG"],
                                fg=p["TEXT_MUTED"], font=_font(8),
                                wraplength=size + 70, justify="center")
            self.sub.pack(pady=(2, 0))

        self._icon_draw = icon_draw
        self._image = image
        self._size = size
        self._hover = False
        self._enabled = True
        self._command = command
        self._redraw()

        widgets = [self.canvas, self.label]
        if self.sub is not None:
            widgets.append(self.sub)
        for widget in widgets:
            widget.bind("<Button-1>", self._click)
            widget.bind("<Enter>", self._enter)
            widget.bind("<Leave>", self._leave)

    def _enter(self, _event) -> None:
        if self._enabled:
            self._hover = True
            self._redraw()

    def _leave(self, _event) -> None:
        self._hover = False
        self._redraw()

    def _click(self, _event) -> None:
        if self._enabled and self._command is not None:
            self._command()

    def set_enabled(self, enabled: bool) -> None:
        self._enabled = enabled
        self._hover = False
        self.frame.configure(cursor="hand2" if enabled else "arrow")
        self._redraw()

    def set_sub(self, text: str) -> None:
        if self.sub is not None:
            self.sub.configure(text=text)

    def _redraw(self) -> None:
        canvas = self.canvas
        canvas.delete("all")
        size = self._size
        p = PALETTE
        if self._enabled and self._hover:
            # Accent glow on hover — a small touch that sets this apart.
            icons.round_rect(canvas, 2, 2, size - 2, size - 2, 22,
                             fill=p["TILE_HOVER"], outline=p["ACCENT"], width=2)
        else:
            fill = p["TILE"] if self._enabled else p["TILE_DISABLED"]
            icons.round_rect(canvas, 2, 2, size - 2, size - 2, 22,
                             fill=fill, outline=p["TILE_BORDER"])
        if self._image is not None:
            canvas.create_image(size / 2, size / 2, image=self._image)
        elif self._icon_draw is not None:
            self._icon_draw(canvas, size / 2, size / 2, size * 0.30)


# --------------------------------------------------------------------------
# Main application
# --------------------------------------------------------------------------

NAV_ITEMS = (
    ("converting", "Converting", icons.draw_reload),
    ("help", "Help", icons.draw_question),
    ("about", "About", icons.draw_info),
    ("settings", "Settings", icons.draw_gear_outline),
    ("news", "News", icons.draw_news),
)

HELP_TEXT = (
    "Systematics TRILLION MIDI maker\n"
    "================================\n\n"
    "1. Click the document in the middle to choose a MIDI file.\n"
    "2. In File properties, tick the track(s) you want to multiply.\n"
    "3. Set the track multiplier (1 to 65,535).\n"
    "4. Press Start.\n\n"
    "What it does\n"
    "------------\n"
    "Each ticked (selected) track is repeated your chosen number of times;\n"
    "unticked tracks are kept exactly once. So a melody track can stay the\n"
    "same while a \"spam\" track is multiplied up to 65,535 times. The total\n"
    "track count is capped at 65,535 (the MIDI limit), so when other tracks\n"
    "are kept the multiplier is reduced automatically to fit.\n\n"
    "Multiple tracks\n"
    "---------------\n"
    "Multi-track MIDI files are supported. Open File properties to see every\n"
    "track (with its note count and name) and choose which ones get\n"
    "multiplied. Your selection is remembered per file.\n\n"
    "Why .xz?\n"
    "--------\n"
    "The uncompressed result can be many gigabytes, but because every track\n"
    "is identical it compresses to almost nothing. The file is stored as a\n"
    "single XZ stream, so decompress it with any tool that understands .xz\n"
    "(7-Zip, `xz -d`, Python's lzma module, …) to get the full multi-track\n"
    ".mid back.\n\n"
    "Fast mode\n"
    "---------\n"
    "Streamed mode (default) compresses the whole file in one pass and gives\n"
    "the smallest output. Fast mode compresses the track once and repeats\n"
    "that block (concatenated XZ streams) — it is nearly instant but larger.\n\n"
    "Compression presets run from 0 (fastest, larger) to 9 (slowest, smallest).\n\n"
    "Double compression\n"
    "------------------\n"
    "Tick \"Double compression\" in Settings to compress the .xz file again into\n"
    "a .xz.xz file. This shrinks Fast-mode output dramatically (and streamed\n"
    "output a little). Decompress twice to get the .mid back.\n\n"
    "Memory\n"
    "------\n"
    "Choosing a file loads every track into RAM, so a 100 MB file uses\n"
    "roughly 100 MB of memory (1 GB file = ~1 GB of RAM). This is why\n"
    "repeated runs are instant: the tracks are never re-read from disk.\n\n"
    "Theme\n"
    "-----\n"
    "Switch between dark and light mode in Settings. The change applies as\n"
    "soon as you save.\n\n"
    "Updates\n"
    "-------\n"
    "The app checks its built-in update feed (hosted on GitHub Pages) on\n"
    "startup, and you can press Settings > Check for updates any time. When\n"
    "a newer version is found you can download and install it in one click\n"
    "— the app backs up the old files and restarts itself.\n\n"
    "News\n"
    "----\n"
    "The bar at the bottom shows announcements published by the app's\n"
    "author. Click it (or \"More News\") to read every article. News loads\n"
    "from the hosted feed automatically on startup.\n"
)

ABOUT_TEXT = (
    f"{APP_NAME}\n"
    f"Version {__version__}\n\n"
    "Turns a MIDI into a gigantic multi-track black MIDI by multiplying\n"
    "the tracks you choose, compressed into a tiny .xz file.\n\n"
    "Built with Python + tkinter. Have fun!\n"
)


class App:
    def __init__(self, root: tk.Tk):
        self.root = root
        self.settings = app_settings.load()
        self._theme_name = self.settings.get("theme", "dark")

        self._queue: queue.Queue = queue.Queue()
        self._cancel = threading.Event()
        self._thread: threading.Thread | None = None
        self._running = False
        self._icon: tk.PhotoImage | None = None

        self._update_queue: queue.Queue = queue.Queue()
        self._update_pending = False
        self._dl_queue: queue.Queue = queue.Queue()
        self._dl_pending = False
        self._dl_widgets = None
        self._dl_dest = ""
        self._load_queue: queue.Queue = queue.Queue()
        self._load_pending = False
        self._load_token = 0
        self._load_manual = False

        self._news_queue: queue.Queue = queue.Queue()
        self._news_pending = False
        self._news_articles: list[dict] = []
        self._news_error = ""
        self._news_window: tk.Toplevel | None = None
        self._news_selected = 0

        self.info: midi_engine.MidiInfo | None = None
        self.track_bytes = 0
        self.selected_tracks: list[int] = []
        self.current_page = "converting"

        root.title(APP_NAME)
        set_palette(self._theme_name)
        apply_theme(root)
        self._build_vars()
        self._load_assets()
        self._build_sidebar()
        self._build_pages()
        self._add_traces()
        self._apply_settings()
        self._select_page("converting")
        self._load_icon()
        _enable_dark_titlebar(root, self._theme_name == "dark")

        self.root.protocol("WM_DELETE_WINDOW", self._on_close)

        if self.settings.get("check_updates"):
            # Let the window appear before any network work.
            self.root.after(1500, lambda: self._check_updates(manual=False))

        if self.settings.get("show_news", True):
            # Fetch announcements in the background; the ticker fills in when
            # the feed arrives and the app stays silent if it can't be reached.
            self.root.after(600, lambda: self._check_news(manual=False))

    # -- state -------------------------------------------------------------

    def _build_vars(self) -> None:
        self.input_var = tk.StringVar(value="")
        self.output_var = tk.StringVar(value="")
        self.multiplier_var = tk.StringVar(value=str(self.settings["multiplier"]))
        self.preset_var = tk.StringVar(value=str(self.settings["compression_preset"]))
        self.fast_var = tk.BooleanVar(value=bool(self.settings["fast_mode"]))
        self.double_var = tk.BooleanVar(value=bool(self.settings["double_compress"]))
        self.remember_var = tk.BooleanVar(value=bool(self.settings["remember_input"]))
        self.auto_var = tk.BooleanVar(value=bool(self.settings["auto_output"]))
        self.theme_var = tk.StringVar(value=self.settings.get("theme", "dark"))
        self.check_updates_var = tk.BooleanVar(
            value=bool(self.settings.get("check_updates", True)))
        self.backup_var = tk.BooleanVar(
            value=bool(self.settings.get("backup_on_update", True)))
        self.update_status_var = tk.StringVar(value="")
        self.show_news_var = tk.BooleanVar(
            value=bool(self.settings.get("show_news", True)))

    def _add_traces(self) -> None:
        self.multiplier_var.trace_add("write", lambda *_: self._refresh_dynamic())
        self.preset_var.trace_add("write", lambda *_: self._refresh_dynamic())
        self.fast_var.trace_add("write", lambda *_: self._refresh_dynamic())
        self.double_var.trace_add("write", lambda *_: self._refresh_dynamic())

    # -- sidebar -----------------------------------------------------------

    def _load_assets(self) -> None:
        base = os.path.join(os.path.dirname(os.path.abspath(__file__)), "assets")
        # Light mode loads the gray set from assets/light/ instead of the
        # blue (dark) set. Every icon in the app ships as a PNG in both sets;
        # the canvas-drawn glyphs in icons.py remain only as a fallback.
        folder = os.path.join(base, "light") if self._theme_name == "light" else base
        self.assets = {}
        for name in ("start", "stop", "gears", "gears_small",
                     "document", "document_card",
                     "hamburger", "reload", "question", "info", "news"):
            path = os.path.join(folder, name + ".png")
            if os.path.isfile(path):
                try:
                    self.assets[name] = tk.PhotoImage(file=path)
                except tk.TclError:
                    self.assets[name] = None
            else:
                self.assets[name] = None

    def _build_sidebar(self) -> None:
        p = PALETTE
        sidebar = tk.Frame(self.root, bg=p["SIDEBAR"], width=220)
        sidebar.pack(side="left", fill="y")
        sidebar.pack_propagate(False)
        self.sidebar = sidebar

        header = tk.Frame(sidebar, bg=p["SIDEBAR_HEADER"], height=44)
        header.pack(fill="x")
        header.pack_propagate(False)
        self.hamburger = tk.Canvas(header, width=30, height=44,
                                   bg=p["SIDEBAR_HEADER"], highlightthickness=0,
                                   bd=0, cursor="hand2")
        self.hamburger.pack(side="left", padx=(7, 6))
        if self.assets.get("hamburger") is not None:
            self.hamburger.create_image(15, 22, image=self.assets["hamburger"])
        else:
            icons.draw_hamburger(self.hamburger, 6, 15, 24, 29)
        self.hamburger.bind("<Button-1>", self._toggle_sidebar)
        self.header_label = tk.Label(header, text="Converting",
                                     bg=p["SIDEBAR_HEADER"], fg=p["TEXT"],
                                     font=_font(11, "bold"))
        self.header_label.pack(side="left")

        self.sidebar_body = tk.Frame(sidebar, bg=p["SIDEBAR"])
        self.sidebar_body.pack(fill="both", expand=True)

        self.nav = {}
        for key, label, icon_fn in NAV_ITEMS:
            item = tk.Frame(self.sidebar_body, bg=p["SIDEBAR"], cursor="hand2")
            item.pack(fill="x")
            bar = tk.Frame(item, bg=p["SIDEBAR"], width=3)
            bar.pack(side="left", fill="y")
            cv = tk.Canvas(item, width=20, height=20, bg=p["SIDEBAR"],
                           highlightthickness=0, bd=0)
            cv.pack(side="left", padx=(17, 12), pady=11)
            icon_name = {"converting": "reload", "help": "question",
                         "about": "info", "settings": "gears_small",
                         "news": "news"}[key]
            if self.assets.get(icon_name) is not None:
                cv.create_image(10, 10, image=self.assets[icon_name])
            else:
                icon_fn(cv, 10, 10, 8)
            lbl = tk.Label(item, text=label, bg=p["SIDEBAR"], fg=p["TEXT"],
                           font=_font(10), anchor="w")
            lbl.pack(side="left", fill="x", expand=True)
            for widget in (cv, lbl):
                widget.bind("<Button-1>", lambda _e, k=key: self._select_page(k))
            self.nav[key] = {"frame": item, "canvas": cv, "label": lbl, "bar": bar}

        footer = tk.Frame(self.sidebar_body, bg=p["SIDEBAR"])
        footer.pack(side="bottom", fill="x", pady=(0, 18))
        tk.Label(footer, text="Systematics TRILLION", bg=p["SIDEBAR"],
                 fg=p["TEXT"], font=_font(9, "bold")).pack(anchor="w", padx=20)
        tk.Label(footer, text=f"MIDI MAKER v{__version__}", bg=p["SIDEBAR"],
                 fg=p["TEXT_MUTED"], font=_font(8)).pack(anchor="w", padx=20)

        self._set_sidebar(False)  # start collapsed

    def _toggle_sidebar(self, _event=None) -> None:
        self._set_sidebar(not self.sidebar_open)

    def _set_sidebar(self, open_: bool) -> None:
        self.sidebar_open = open_
        if open_:
            self.sidebar.configure(width=220)
            self.header_label.pack(side="left")
            self.sidebar_body.pack(fill="both", expand=True)
        else:
            self.sidebar.configure(width=44)
            self.header_label.pack_forget()
            self.sidebar_body.pack_forget()

    # -- news ticker -------------------------------------------------------

    def _build_news_bar(self, parent: tk.Frame) -> None:
        """Build the bottom ticker bar (hidden when show_news is off)."""
        self.news_bar = None
        if not self.settings.get("show_news", True):
            return
        p = PALETTE
        outer = tk.Frame(parent, bg=p["CARD_BORDER"])
        outer.pack(side="bottom", fill="x")
        bar = tk.Frame(outer, bg=p["NEWS_BG"], height=32)
        bar.pack(fill="x", pady=(1, 0))
        bar.pack_propagate(False)
        self.news_bar = bar

        # Decorative drag-handle dots (echoes the reference news strip).
        handle = tk.Canvas(bar, width=18, height=32, bg=p["NEWS_BG"],
                           highlightthickness=0, bd=0)
        handle.pack(side="left", padx=(10, 6))
        for col in range(2):
            for row in range(3):
                x = 5 + col * 6
                y = 9 + row * 6
                handle.create_oval(x - 1, y - 1, x + 1, y + 1,
                                   fill=p["TEXT_MUTED"], outline=p["TEXT_MUTED"])

        img = self.assets.get("news")
        icon = tk.Label(bar, bg=p["NEWS_BG"], cursor="hand2")
        if img is not None:
            icon.configure(image=img)
        icon.pack(side="left", padx=(0, 8))

        self.news_title_var = tk.StringVar(value=self._news_ticker_text())
        title = tk.Label(bar, textvariable=self.news_title_var, bg=p["NEWS_BG"],
                         fg=p["TEXT"], font=_font(9), anchor="w")
        title.pack(side="left")

        sep = tk.Frame(bar, bg=p["CARD_BORDER"], width=1)
        sep.pack(side="right", fill="y", padx=(8, 0))
        more = tk.Label(bar, text="More News", bg=p["NEWS_BG"], fg=p["TEXT"],
                        font=_font(9, "bold"), cursor="hand2", padx=10)
        if img is not None:
            more.configure(image=img, compound="left")
        more.pack(side="right", fill="y")

        for widget in (icon, title, more):
            widget.bind("<Button-1>", lambda _e: self._open_news_window())

    def _news_ticker_text(self) -> str:
        """One-line headline for the ticker (truncated so it never overflows)."""
        if self._news_articles:
            text = self._news_articles[0]["summary"] or self._news_articles[0]["title"]
        elif self._news_pending:
            return "Checking for news…"
        elif self._news_error:
            return "News unavailable — click for details"
        else:
            return "No news yet"
        if len(text) > 88:
            text = text[:85] + "…"
        return text

    def _check_news(self, manual: bool = False) -> None:
        if self._news_pending:
            return
        self._news_pending = True
        if hasattr(self, "news_title_var"):
            self.news_title_var.set("Checking for news…")
        threading.Thread(target=self._news_worker,
                         args=(NEWS_FEED_URL, manual), daemon=True).start()
        self.root.after(200, self._poll_news)

    def _news_worker(self, url: str, manual: bool) -> None:
        try:
            articles = app_news.fetch_news(url)
            self._news_queue.put(("ok", articles, manual))
        except app_news.NewsError as exc:
            self._news_queue.put(("error", str(exc), manual))

    def _poll_news(self) -> None:
        drained = False
        try:
            while True:
                msg = self._news_queue.get_nowait()
                drained = True
                kind = msg[0]
                if kind == "ok":
                    self._news_articles = msg[1]
                    self._news_error = ""
                    _console(f"[Systematics] News: {len(self._news_articles)} article(s)")
                    if hasattr(self, "news_title_var"):
                        self.news_title_var.set(self._news_ticker_text())
                    if msg[2]:
                        self._news_refresh_window()
                else:
                    self._news_error = msg[1]
                    _console(f"[Systematics] News failed: {msg[1]}")
                    if hasattr(self, "news_title_var"):
                        self.news_title_var.set(self._news_ticker_text())
                    if msg[2]:
                        self._news_refresh_window()
                        messagebox.showerror(
                            APP_NAME, f"Could not load the news feed:\n\n{msg[1]}",
                            parent=self.root)
        except queue.Empty:
            pass
        if drained:
            self._news_pending = False
            return
        if self._news_pending:
            self.root.after(200, self._poll_news)

    def _open_news_window(self) -> None:
        if self._news_window is not None:
            try:
                if self._news_window.winfo_exists():
                    self._news_window.lift()
                    self._news_window.focus_force()
                    return
            except tk.TclError:
                pass
        p = PALETTE
        win = tk.Toplevel(self.root)
        win.title(f"News — {APP_NAME}")
        win.geometry("780x500")
        win.configure(bg=p["MAIN_BG"])
        win.transient(self.root)
        self._apply_dialog_titlebar(win)
        self._news_window = win

        left = tk.Frame(win, bg=p["SIDEBAR"], width=260)
        left.pack(side="left", fill="y")
        left.pack_propagate(False)
        tk.Label(left, text="News", bg=p["SIDEBAR"], fg=p["ACCENT"],
                 font=_font(14, "bold")).pack(anchor="w", padx=16, pady=(16, 10))
        self._news_list_frame = tk.Frame(left, bg=p["SIDEBAR"])
        self._news_list_frame.pack(fill="both", expand=True)

        right = tk.Frame(win, bg=p["MAIN_BG"])
        right.pack(side="left", fill="both", expand=True)
        self._news_title_lbl = tk.Label(right, text="", bg=p["MAIN_BG"],
                                        fg=p["ACCENT"], font=_font(14, "bold"),
                                        anchor="w", justify="left")
        self._news_title_lbl.pack(fill="x", padx=18, pady=(16, 2))
        self._news_date_lbl = tk.Label(right, text="", bg=p["MAIN_BG"],
                                       fg=p["TEXT_MUTED"], font=_font(9), anchor="w")
        self._news_date_lbl.pack(fill="x", padx=18)

        body_frame = tk.Frame(right, bg=p["MAIN_BG"])
        body_frame.pack(fill="both", expand=True, padx=18, pady=(8, 8))
        self._news_body = tk.Text(body_frame, bg=p["CARD"], fg=p["TEXT"],
                                  insertbackground=p["TEXT"], relief="flat",
                                  wrap="word", font=_font(10), padx=12, pady=10,
                                  highlightthickness=0)
        scroll = ttk.Scrollbar(body_frame, command=self._news_body.yview)
        self._news_body.configure(yscrollcommand=scroll.set)
        self._news_body.pack(side="left", fill="both", expand=True)
        scroll.pack(side="right", fill="y")

        bottom = tk.Frame(win, bg=p["SIDEBAR"])
        bottom.pack(side="bottom", fill="x")
        self._news_link_btn = tk.Button(
            bottom, text="Open link", state="disabled",
            command=self._open_news_link, bg=p["BUTTON_SECONDARY"], fg=p["TEXT"],
            activebackground=p["BUTTON_SECONDARY_HOVER"],
            activeforeground=p["TEXT"], relief="flat", padx=12, pady=6,
            font=_font(9), cursor="hand2")
        self._news_link_btn.pack(side="left", padx=(12, 6), pady=10)
        tk.Button(bottom, text="Refresh news",
                  command=lambda: self._check_news(manual=True),
                  bg=p["ACCENT"], fg=p["ACCENT_ON"],
                  activebackground=p["ACCENT_HOVER"],
                  activeforeground=p["ACCENT_ON"], relief="flat", padx=12,
                  pady=6, font=_font(9, "bold"), cursor="hand2").pack(
            side="left", padx=(12, 6), pady=10)
        tk.Button(bottom, text="Close", command=win.destroy, bg=p["ACCENT"],
                  fg=p["ACCENT_ON"], activebackground=p["ACCENT_HOVER"],
                  activeforeground=p["ACCENT_ON"], relief="flat", padx=16,
                  pady=6, font=_font(9, "bold"), cursor="hand2").pack(
            side="right", padx=12, pady=10)

        self._news_selected = 0
        self._populate_news_list()
        win.protocol("WM_DELETE_WINDOW", self._close_news_window)

    def _close_news_window(self) -> None:
        if self._news_window is not None:
            try:
                self._news_window.destroy()
            except tk.TclError:
                pass
        self._news_window = None

    def _news_refresh_window(self) -> None:
        if self._news_window is not None:
            try:
                if self._news_window.winfo_exists():
                    self._populate_news_list()
            except tk.TclError:
                pass

    def _populate_news_list(self) -> None:
        if not hasattr(self, "_news_list_frame"):
            return
        for child in self._news_list_frame.winfo_children():
            child.destroy()
        p = PALETTE
        if self._news_pending and not self._news_articles:
            tk.Label(self._news_list_frame, text="Loading news…", bg=p["SIDEBAR"],
                     fg=p["TEXT_MUTED"], font=_font(9)).pack(
                anchor="w", padx=16, pady=8)
        elif not self._news_articles:
            tk.Label(self._news_list_frame,
                     text=self._news_error or "No news yet.",
                     bg=p["SIDEBAR"], fg=p["TEXT_MUTED"], font=_font(9),
                     wraplength=220, justify="left").pack(
                anchor="w", padx=16, pady=8)
        else:
            for i, art in enumerate(self._news_articles):
                btn = tk.Button(
                    self._news_list_frame, text=art["title"], anchor="w",
                    justify="left", wraplength=220,
                    command=lambda idx=i: self._show_news_article(idx),
                    bg=p["SIDEBAR"], fg=p["TEXT"],
                    activebackground=p["NAV_ACTIVE"], activeforeground=p["TEXT"],
                    relief="flat", padx=12, pady=8, font=_font(9), cursor="hand2")
                btn.pack(fill="x", padx=8, pady=2)
        self._show_news_article(self._news_selected if self._news_articles else 0)

    def _show_news_article(self, index: int) -> None:
        if index < len(self._news_articles):
            self._news_selected = index
        if not hasattr(self, "_news_title_lbl"):
            return
        if not self._news_articles:
            self._news_title_lbl.configure(text="")
            self._news_date_lbl.configure(text="")
            self._news_body.configure(state="normal")
            self._news_body.delete("1.0", "end")
            self._news_body.insert("1.0", self._news_error or "No news yet.")
            self._news_body.configure(state="disabled")
            self._news_link_btn.configure(state="disabled")
            return
        index = min(max(index, 0), len(self._news_articles) - 1)
        art = self._news_articles[index]
        self._news_title_lbl.configure(text=art["title"])
        self._news_date_lbl.configure(text=art["date"])
        self._news_body.configure(state="normal")
        self._news_body.delete("1.0", "end")
        self._news_body.insert("1.0", (art["body"] or art["summary"]).strip())
        self._news_body.configure(state="disabled")
        if art["url"]:
            self._news_link_btn.configure(state="normal")
            self._news_url = art["url"]
        else:
            self._news_link_btn.configure(state="disabled")
            self._news_url = ""

    def _open_news_link(self) -> None:
        if getattr(self, "_news_url", ""):
            webbrowser.open(self._news_url)

    # -- pages -------------------------------------------------------------

    def _build_pages(self) -> None:
        p = PALETTE
        self.content = tk.Frame(self.root, bg=p["MAIN_BG"])
        self.content.pack(side="left", fill="both", expand=True)

        # Small brand bar across the top of the main area.
        topbar = tk.Frame(self.content, bg=p["SIDEBAR_HEADER"], height=44)
        topbar.pack(side="top", fill="x")
        topbar.pack_propagate(False)
        tk.Label(topbar, text="Systematics", bg=p["SIDEBAR_HEADER"],
                 fg=p["ACCENT"], font=_font(12, "bold")).pack(side="left",
                                                              padx=(18, 0))
        tk.Label(topbar, text="TRILLION MIDI maker", bg=p["SIDEBAR_HEADER"],
                 fg=p["TEXT"], font=_font(12, "bold")).pack(side="left")
        tk.Label(topbar, text=f"v{__version__}", bg=p["SIDEBAR_HEADER"],
                 fg=p["TEXT_MUTED"], font=_font(9)).pack(side="right", padx=18)

        # News ticker docked to the bottom of the main area.
        self._build_news_bar(self.content)

        self.page_host = tk.Frame(self.content, bg=p["MAIN_BG"])
        self.page_host.pack(side="top", fill="both", expand=True)
        self.page_host.rowconfigure(0, weight=1)
        self.page_host.columnconfigure(0, weight=1)

        self.pages = {}
        for key, _label, _icon in NAV_ITEMS:
            page = tk.Frame(self.page_host, bg=p["MAIN_BG"])
            page.grid(row=0, column=0, sticky="nsew")
            self.pages[key] = page

        self._build_converting(self.pages["converting"])
        self._build_text_page(self.pages["help"], HELP_TEXT)
        self._build_text_page(self.pages["about"], ABOUT_TEXT)
        self._build_settings(self.pages["settings"])

    def _select_page(self, key: str) -> None:
        if key == "news":
            # News is a popup window, not an in-place page.
            self._open_news_window()
            return
        self.current_page = key
        self.pages[key].tkraise()
        label = dict((k, l) for k, l, _ in NAV_ITEMS)[key]
        self.header_label.configure(text=label)
        for nav_key, item in self.nav.items():
            active = nav_key == key
            bg = PALETTE["NAV_ACTIVE"] if active else PALETTE["SIDEBAR"]
            item["frame"].configure(bg=bg)
            item["canvas"].configure(bg=bg)
            item["label"].configure(
                bg=bg, fg=PALETTE["ACCENT"] if active else PALETTE["TEXT"])
            item["bar"].configure(
                bg=PALETTE["ACCENT"] if active else PALETTE["SIDEBAR"])
        if key == "settings":
            self._refresh_dynamic()

    # -- converting page ---------------------------------------------------

    def _build_converting(self, page: tk.Frame) -> None:
        p = PALETTE
        page.columnconfigure(0, weight=0)
        page.columnconfigure(1, weight=1)
        page.columnconfigure(2, weight=0)
        page.rowconfigure(0, weight=1)
        page.rowconfigure(1, weight=1)

        pad = 24
        self.start_tile = Tile(page, "Start", image=self.assets.get("start"),
                               command=self.start_generate)
        self.start_tile.frame.grid(row=0, column=0, sticky="nw",
                                   padx=(pad, 14), pady=(pad, 12))

        self.interrupt_tile = Tile(page, "Stop",
                                   image=self.assets.get("stop"),
                                   command=self.request_cancel)
        self.interrupt_tile.frame.grid(row=1, column=0, sticky="sw",
                                       padx=(pad, 14), pady=(12, pad))
        self.interrupt_tile.set_enabled(False)

        self.customise_tile = Tile(page, "Customise",
                                   subtext="",
                                   image=self.assets.get("gears"),
                                   command=self._open_settings_page)
        self.customise_tile.frame.grid(row=0, column=2, sticky="ne",
                                       padx=(14, pad), pady=(pad, 12))

        self.props_tile = Tile(page, "File properties",
                               image=self.assets.get("document"),
                               command=self.show_file_properties)
        self.props_tile.frame.grid(row=1, column=2, sticky="se",
                                   padx=(14, pad), pady=(12, pad))

        # Central document card.
        card_frame = tk.Frame(page, bg=p["MAIN_BG"])
        card_frame.grid(row=0, column=1, rowspan=2, sticky="nsew",
                        pady=(pad, pad))
        self.card = tk.Canvas(card_frame, bg=p["MAIN_BG"], highlightthickness=0,
                              bd=0, cursor="hand2")
        self.card.pack(fill="both", expand=True)
        self.card.bind("<Button-1>", lambda _e: self.choose_input())
        self.card.bind("<Configure>", lambda _e: self._redraw_card())

        # Multiplier row.
        controls = tk.Frame(page, bg=p["MAIN_BG"])
        controls.grid(row=2, column=0, columnspan=3, sticky="ew",
                      padx=pad, pady=(0, 4))
        tk.Label(controls, text="Tracks ×", bg=p["MAIN_BG"], fg=p["TEXT"],
                 font=_font(10)).pack(side="left")
        ttk.Spinbox(controls, from_=1, to=65535, width=12,
                    textvariable=self.multiplier_var).pack(side="left", padx=8)
        self.output_hint = tk.Label(controls, text="", bg=p["MAIN_BG"],
                                    fg=p["TEXT_MUTED"], font=_font(9))
        self.output_hint.pack(side="left")

        # Loading progress — shown while a MIDI parses in the background.
        self.load_progress = ttk.Progressbar(
            page, style="Accent.Horizontal.TProgressbar", mode="indeterminate")
        self.load_progress.grid(row=3, column=0, columnspan=3, sticky="ew",
                                padx=pad, pady=(4, 0))
        self.load_progress.grid_remove()
        self.load_info_var = tk.StringVar(value="")
        self.load_info = tk.Label(page, textvariable=self.load_info_var,
                                  bg=p["MAIN_BG"], fg=p["TEXT_MUTED"],
                                  font=_font(9), anchor="w")
        self.load_info.grid(row=4, column=0, columnspan=3, sticky="ew",
                            padx=pad, pady=(2, 0))
        self.load_info.grid_remove()

        self.progress = ttk.Progressbar(page, style="Accent.Horizontal.TProgressbar",
                                        mode="determinate", maximum=1, value=0)
        self.progress.grid(row=5, column=0, columnspan=3, sticky="ew",
                           padx=pad, pady=(6, 6))

        status = tk.Frame(page, bg=p["MAIN_BG"])
        status.grid(row=6, column=0, columnspan=3, sticky="ew",
                    padx=pad, pady=(0, pad))
        self.track_status_var = tk.StringVar(value="Ready.")
        tk.Label(status, textvariable=self.track_status_var, bg=p["MAIN_BG"],
                 fg=p["TEXT"], font=_font(10)).pack(anchor="w")
        self.file_status_var = tk.StringVar(value="Currently chosen file: None")
        tk.Label(status, textvariable=self.file_status_var, bg=p["MAIN_BG"],
                 fg=p["TEXT_MUTED"], font=_font(9)).pack(anchor="w", pady=(2, 0))

    def _redraw_card(self) -> None:
        canvas = self.card
        width = canvas.winfo_width()
        height = canvas.winfo_height()
        if width < 8 or height < 8:
            return
        p = PALETTE
        canvas.delete("all")
        icons.round_rect(canvas, 4, 4, width - 4, height - 4, 18,
                         fill=p["CARD"], outline=p["CARD_BORDER"])
        cx = width / 2
        img = self.assets.get("document_card")
        if img is not None:
            cy = max(img.height() / 2 + 10, (height - 96) / 2)
            canvas.create_image(cx, cy, image=img)
            label_y = cy + img.height() / 2 + 16
        else:
            cy = height / 2 - 22
            rh = min(height * 0.30, width * 0.24)
            rw = rh * 0.9
            icons.draw_document(canvas, cx - rw, cy - rh, cx + rw, cy + rh)
            label_y = cy + rh + 30
        if self.info is not None:
            name = os.path.basename(self.input_var.get()) or "Untitled"
            canvas.create_text(cx, label_y, text=name, fill=p["TEXT"],
                               font=_font(11, "bold"), width=width - 60)
            ntrks = max(1, len(self.info.track_chunks))
            line = (f"{self.info.note_count:,} notes · {ntrks} track"
                    f"{'' if ntrks == 1 else 's'}")
            if ntrks > 1:
                line += f" · {len(self.selected_tracks)} to multiply"
            line += f" · {midi_engine.human_size(self.track_bytes)} in RAM"
            canvas.create_text(cx, label_y + 24, text=line,
                               fill=p["TEXT_MUTED"], font=_font(9), width=width - 60)
        elif self.input_var.get().strip():
            name = os.path.basename(self.input_var.get())
            canvas.create_text(cx, label_y, text=name, fill=p["TEXT"],
                               font=_font(11, "bold"), width=width - 60)
            canvas.create_text(cx, label_y + 24, text="Loading…",
                               fill=p["TEXT_MUTED"], font=_font(9),
                               width=width - 60)
        else:
            canvas.create_text(cx, label_y,
                               text="Click to choose a MIDI file",
                               fill=p["TEXT_MUTED"], font=_font(10), width=width - 60)

    # -- help / about pages ------------------------------------------------

    def _build_text_page(self, page: tk.Frame, body: str) -> None:
        p = PALETTE
        wrap = tk.Frame(page, bg=p["MAIN_BG"])
        wrap.pack(fill="both", expand=True, padx=24, pady=24)
        text = tk.Text(wrap, bg=p["CARD"], fg=p["TEXT"], insertbackground=p["TEXT"],
                       relief="flat", wrap="word", font=_font(10),
                       padx=14, pady=12, highlightthickness=0)
        scroll = ttk.Scrollbar(wrap, command=text.yview)
        text.configure(yscrollcommand=scroll.set)
        text.pack(side="left", fill="both", expand=True)
        scroll.pack(side="right", fill="y")
        text.insert("1.0", body)
        text.configure(state="disabled")

    # -- settings page -----------------------------------------------------

    def _build_settings(self, page: tk.Frame) -> None:
        p = PALETTE
        form = tk.Frame(page, bg=p["MAIN_BG"])
        form.pack(anchor="nw", padx=28, pady=26)

        tk.Label(form, text="Settings", bg=p["MAIN_BG"], fg=p["ACCENT"],
                 font=_font(16, "bold")).grid(row=0, column=0, columnspan=3,
                                              sticky="w", pady=(0, 10))

        # Appearance.
        tk.Label(form, text="Theme", bg=p["MAIN_BG"], fg=p["TEXT"],
                 font=_font(10)).grid(row=1, column=0, sticky="w", pady=4)
        theme_row = tk.Frame(form, bg=p["MAIN_BG"])
        theme_row.grid(row=1, column=1, columnspan=2, sticky="w",
                       padx=(12, 0), pady=4)
        ttk.Radiobutton(theme_row, text="Dark mode", value="dark",
                        variable=self.theme_var).pack(side="left")
        ttk.Radiobutton(theme_row, text="Light mode", value="light",
                        variable=self.theme_var).pack(side="left", padx=(16, 0))

        # Duplication.
        tk.Label(form, text="Default multiplier", bg=p["MAIN_BG"], fg=p["TEXT"],
                 font=_font(10)).grid(row=2, column=0, sticky="w", pady=4)
        ttk.Spinbox(form, from_=1, to=65535, width=12,
                    textvariable=self.multiplier_var).grid(
            row=2, column=1, sticky="w", padx=(12, 0), pady=4)

        tk.Label(form, text="Compression preset", bg=p["MAIN_BG"], fg=p["TEXT"],
                 font=_font(10)).grid(row=3, column=0, sticky="w", pady=4)
        ttk.Combobox(form, width=6, state="readonly",
                     values=[str(i) for i in range(10)],
                     textvariable=self.preset_var).grid(
            row=3, column=1, sticky="w", padx=(12, 0), pady=4)
        tk.Label(form, text="0 = fastest · 9 = smallest", bg=p["MAIN_BG"],
                 fg=p["TEXT_MUTED"], font=_font(9)).grid(
            row=3, column=2, sticky="w", padx=(10, 0), pady=4)

        ttk.Checkbutton(form, text="Fast mode (concatenated streams — near instant, larger file)",
                        variable=self.fast_var).grid(
            row=4, column=0, columnspan=3, sticky="w", pady=(10, 0))
        ttk.Checkbutton(form, text="Double compression (.xz.xz — saves more storage, mainly for Fast mode)",
                        variable=self.double_var).grid(
            row=5, column=0, columnspan=3, sticky="w", pady=(4, 0))
        ttk.Checkbutton(form, text="Remember last input file",
                        variable=self.remember_var).grid(
            row=6, column=0, columnspan=3, sticky="w", pady=(4, 0))
        ttk.Checkbutton(form, text="Suggest an output path automatically",
                        variable=self.auto_var).grid(
            row=7, column=0, columnspan=3, sticky="w", pady=(4, 0))

        # Updates.
        ttk.Checkbutton(form, text="Check for updates on startup",
                        variable=self.check_updates_var).grid(
            row=8, column=0, columnspan=3, sticky="w", pady=(10, 0))
        ttk.Checkbutton(form, text="Save a backup of the current files when installing an update",
                        variable=self.backup_var).grid(
            row=9, column=0, columnspan=3, sticky="w", pady=(4, 0))

        # News.
        ttk.Checkbutton(form, text="Show the news bar at the bottom",
                        variable=self.show_news_var).grid(
            row=10, column=0, columnspan=3, sticky="w", pady=(10, 0))

        update_row = tk.Frame(form, bg=p["MAIN_BG"])
        update_row.grid(row=11, column=0, columnspan=3, sticky="w", pady=(6, 0))
        tk.Button(update_row, text="Check for updates",
                  command=lambda: self._check_updates(manual=True),
                  bg=p["ACCENT"], fg=p["ACCENT_ON"],
                  activebackground=p["ACCENT_HOVER"],
                  activeforeground=p["ACCENT_ON"], relief="flat", padx=14,
                  pady=6, font=_font(9, "bold"), cursor="hand2").pack(
            side="left")
        tk.Label(update_row, textvariable=self.update_status_var,
                 bg=p["MAIN_BG"], fg=p["TEXT_MUTED"], font=_font(9)).pack(
            side="left", padx=(12, 0))

        buttons = tk.Frame(form, bg=p["MAIN_BG"])
        buttons.grid(row=12, column=0, columnspan=3, sticky="w", pady=(16, 0))
        tk.Button(buttons, text="Save settings", command=self._save_settings,
                  bg=p["ACCENT"], fg=p["ACCENT_ON"],
                  activebackground=p["ACCENT_HOVER"],
                  activeforeground=p["ACCENT_ON"], relief="flat", padx=16,
                  pady=8, font=_font(10, "bold"), cursor="hand2").pack(
            side="left", padx=(0, 8))
        tk.Button(buttons, text="Reset defaults", command=self._reset_settings,
                  bg=p["BUTTON_SECONDARY"], fg=p["TEXT"],
                  activebackground=p["BUTTON_SECONDARY_HOVER"],
                  activeforeground=p["TEXT"], relief="flat", padx=16, pady=8,
                  font=_font(10), cursor="hand2").pack(side="left")

    def _open_settings_page(self) -> None:
        self._select_page("settings")

    def _save_settings(self) -> None:
        try:
            multiplier = int(self.multiplier_var.get())
        except (ValueError, tk.TclError):
            messagebox.showerror(APP_NAME, "Multiplier must be a whole number.",
                                 parent=self.root)
            return
        if not 1 <= multiplier <= 65535:
            messagebox.showerror(APP_NAME, "Multiplier must be between 1 and 65535.",
                                 parent=self.root)
            return
        theme = self.theme_var.get()
        theme_changed = theme != self._theme_name
        news_changed = (bool(self.show_news_var.get())
                        != bool(self.settings.get("show_news", True)))
        self.settings.update({
            "multiplier": multiplier,
            "compression_preset": int(self.preset_var.get()),
            "fast_mode": bool(self.fast_var.get()),
            "double_compress": bool(self.double_var.get()),
            "remember_input": bool(self.remember_var.get()),
            "auto_output": bool(self.auto_var.get()),
            "theme": theme,
            "check_updates": bool(self.check_updates_var.get()),
            "backup_on_update": bool(self.backup_var.get()),
            "show_news": bool(self.show_news_var.get()),
        })
        self._persist()
        if theme_changed or news_changed:
            self._rebuild()
        else:
            self._refresh_dynamic()
        messagebox.showinfo(APP_NAME, "Settings saved.", parent=self.root)

    def _reset_settings(self) -> None:
        if not messagebox.askyesno(
                APP_NAME,
                "Reset all settings to their defaults?",
                parent=self.root):
            return
        self.settings = app_settings.reset()
        theme_changed = self.settings["theme"] != self._theme_name
        news_changed = (bool(self.settings.get("show_news", True))
                        != bool(self.show_news_var.get()))
        self.multiplier_var.set(str(self.settings["multiplier"]))
        self.preset_var.set(str(self.settings["compression_preset"]))
        self.fast_var.set(bool(self.settings["fast_mode"]))
        self.double_var.set(bool(self.settings["double_compress"]))
        self.remember_var.set(bool(self.settings["remember_input"]))
        self.auto_var.set(bool(self.settings["auto_output"]))
        self.theme_var.set(self.settings["theme"])
        self.check_updates_var.set(bool(self.settings["check_updates"]))
        self.backup_var.set(bool(self.settings["backup_on_update"]))
        self.show_news_var.set(bool(self.settings["show_news"]))
        if self.info is not None:
            self.selected_tracks = list(range(len(self.info.track_chunks)))
        self._persist()
        if theme_changed or news_changed:
            self._rebuild()
        else:
            self._refresh_dynamic()

    def _rebuild(self) -> None:
        """Rebuild the widget tree after a theme change (state is kept)."""
        page = self.current_page
        self._theme_name = self.settings.get("theme", "dark")
        set_palette(self._theme_name)
        apply_theme(self.root)
        _enable_dark_titlebar(self.root, self._theme_name == "dark")
        self.sidebar.destroy()
        self.content.destroy()
        self._load_assets()  # swap to the dark/light icon set
        self._build_sidebar()
        self._build_pages()
        self._apply_settings(skip_validate=True)
        self._select_page(page)
        self._refresh_dynamic()

    # -- update checking ---------------------------------------------------

    def _check_updates(self, manual: bool = False) -> None:
        if self._update_pending:
            return
        self._update_pending = True
        if manual:
            self.update_status_var.set("Checking for updates…")
        threading.Thread(target=self._update_worker,
                         args=(UPDATE_FEED_URL, manual), daemon=True).start()
        self.root.after(200, self._poll_updates)

    def _update_worker(self, url: str, manual: bool) -> None:
        try:
            feed = updater.fetch_feed(url)
            if feed is None:
                self._update_queue.put(("none", manual))
            elif updater.is_newer(feed["version"], __version__):
                self._update_queue.put(("available", feed, manual))
            else:
                self._update_queue.put(("current", feed, manual))
        except updater.UpdateError as exc:
            self._update_queue.put(("error", str(exc), manual))

    def _poll_updates(self) -> None:
        drained = False
        try:
            while True:
                msg = self._update_queue.get_nowait()
                drained = True
                kind = msg[0]
                if kind == "available":
                    self._show_update_available(msg[1])
                elif kind == "current":
                    if msg[2]:
                        self.update_status_var.set(
                            f"You're up to date (v{__version__}).")
                        self._show_up_to_date(msg[1])
                elif kind == "none":
                    if msg[2]:
                        self.update_status_var.set("No update feed URL configured.")
                elif kind == "error":
                    if msg[2]:
                        self.update_status_var.set("Update check failed.")
                        messagebox.showerror(APP_NAME, msg[1], parent=self.root)
        except queue.Empty:
            pass
        if drained:
            self._update_pending = False
            return
        if self._update_pending:
            self.root.after(200, self._poll_updates)

    def _show_update_available(self, feed: dict) -> None:
        self.update_status_var.set(f"Update available: v{feed['version']}.")
        self._show_update_dialog(feed)

    def _show_update_dialog(self, feed: dict) -> None:
        p = PALETTE
        win = tk.Toplevel(self.root)
        win.title(f"Update available — {APP_NAME}")
        win.configure(bg=p["MAIN_BG"])
        win.resizable(False, False)
        win.transient(self.root)
        self._apply_dialog_titlebar(win)

        frame = tk.Frame(win, bg=p["MAIN_BG"], padx=22, pady=18)
        frame.pack(fill="both", expand=True)
        tk.Label(frame, text="An update is available!", bg=p["MAIN_BG"],
                 fg=p["ACCENT"], font=_font(14, "bold")).pack(anchor="w")
        tk.Label(frame,
                 text=f"Version {feed['version']}  (you have {__version__})",
                 bg=p["MAIN_BG"], fg=p["TEXT"], font=_font(10)).pack(
            anchor="w", pady=(4, 8))
        if feed["notes"]:
            notes = tk.Text(frame, bg=p["CARD"], fg=p["TEXT"],
                            insertbackground=p["TEXT"], relief="flat",
                            wrap="word", font=_font(10), height=6, width=52,
                            padx=10, pady=8, highlightthickness=0)
            notes.insert("1.0", feed["notes"].rstrip())
            notes.configure(state="disabled")
            notes.pack(fill="both", expand=True, pady=(0, 10))

        status_lbl = tk.Label(frame, text="", bg=p["MAIN_BG"],
                              fg=p["TEXT_MUTED"], font=_font(9))
        status_lbl.pack(anchor="w")
        bar = ttk.Progressbar(frame, style="Accent.Horizontal.TProgressbar",
                              mode="determinate", maximum=1, value=0)

        row = tk.Frame(frame, bg=p["MAIN_BG"])
        row.pack(fill="x", pady=(12, 0))
        later_btn = tk.Button(row, text="Later", command=win.destroy,
                              bg=p["BUTTON_SECONDARY"], fg=p["TEXT"],
                              activebackground=p["BUTTON_SECONDARY_HOVER"],
                              activeforeground=p["TEXT"], relief="flat",
                              padx=16, pady=8, font=_font(10),
                              cursor="hand2")
        install_btn = tk.Button(
            row, text="Download & install",
            command=lambda: self._start_download(feed, win, bar, status_lbl,
                                                 install_btn, later_btn),
            bg=p["ACCENT"], fg=p["ACCENT_ON"],
            activebackground=p["ACCENT_HOVER"],
            activeforeground=p["ACCENT_ON"], relief="flat", padx=16, pady=8,
            font=_font(10, "bold"), cursor="hand2")
        install_btn.pack(side="left")
        later_btn.pack(side="left", padx=(8, 0))
        if not (feed.get("url") or "").strip():
            install_btn.configure(
                text="No download link", state="disabled",
                command=lambda: messagebox.showinfo(
                    APP_NAME,
                    "This update has no download link yet.\n\n"
                    "Check the project's GitHub page for the latest release.",
                    parent=self.root))
        win.grab_set()

    def _start_download(self, feed, win, bar, status_lbl, install_btn,
                        later_btn) -> None:
        url = (feed.get("url") or "").strip()
        if not url:
            return
        install_btn.configure(state="disabled")
        later_btn.configure(state="disabled")
        status_lbl.configure(text="Downloading update…")
        bar.pack(fill="x", pady=(6, 0))
        dest = os.path.join(tempfile.gettempdir(),
                            f"systematics_update_{feed['version']}.zip")
        self._dl_widgets = (win, bar, status_lbl, install_btn, later_btn)
        self._dl_dest = dest
        self._dl_pending = True
        threading.Thread(target=self._download_worker, args=(url, dest, feed),
                         daemon=True).start()
        self.root.after(100, self._poll_download)

    def _download_worker(self, url: str, dest: str, feed: dict) -> None:
        try:
            updater.download(url, dest, progress_cb=self._dl_progress)
            self._dl_queue.put(("dlresult", "ok", feed, dest))
        except updater.UpdateError as exc:
            self._dl_queue.put(("dlresult", "error", str(exc)))

    def _dl_progress(self, done: int, total: int) -> None:
        self._dl_queue.put(("dlprogress", done, total))

    def _poll_download(self) -> None:
        drained = False
        try:
            while True:
                msg = self._dl_queue.get_nowait()
                drained = True
                kind = msg[0]
                if kind == "dlprogress":
                    if self._dl_widgets is None:
                        continue
                    win, bar, status_lbl, install_btn, later_btn = self._dl_widgets
                    if not win.winfo_exists():
                        self._dl_pending = False
                        self._dl_widgets = None
                        return
                    _, done, total = msg
                    bar.configure(maximum=total or 1, value=done)
                    status_lbl.configure(
                        text=f"Downloading… {midi_engine.human_size(done)} / "
                             f"{midi_engine.human_size(total)}")
                elif kind == "dlresult":
                    self._dl_pending = False
                    if msg[1] == "ok":
                        self._install_downloaded(msg[2], msg[3])
                    else:
                        self._download_failed(msg[2])
        except queue.Empty:
            pass
        if drained and not self._dl_pending:
            self._dl_widgets = None
            return
        if self._dl_pending:
            self.root.after(100, self._poll_download)

    def _install_downloaded(self, feed: dict, dest: str) -> None:
        if self._dl_widgets is None:
            return
        win, bar, status_lbl, install_btn, later_btn = self._dl_widgets
        try:
            updater.validate_update_zip(dest)
        except updater.UpdateError as exc:
            status_lbl.configure(text=f"Invalid update package: {exc}")
            later_btn.configure(state="normal")
            return
        status_lbl.configure(text="Download complete. Ready to install.")
        bar.configure(value=bar.cget("maximum"))
        install_btn.configure(
            text="Install & restart", state="normal",
            command=lambda: self._apply_and_restart(feed, dest, win))

    def _apply_and_restart(self, feed: dict, dest: str, win) -> None:
        win.destroy()
        keep_backup = bool(self.settings.get("backup_on_update", True))
        msg = (
            f"Install version {feed['version']}?\n\n"
            "The app will close and restart with the new version.\n"
            + ("A backup of the current files is kept next to the app."
               if keep_backup else
               "No backup will be saved (backups are turned off in Settings)."))
        if not messagebox.askyesno(APP_NAME, msg, parent=self.root):
            return
        app_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        try:
            updater.apply_update(dest, app_root, backup=keep_backup)
        except updater.UpdateError as exc:
            messagebox.showerror(APP_NAME, f"Update failed: {exc}",
                                 parent=self.root)
            return
        self._persist()
        try:
            script = os.path.join(app_root, "trillion.py")
            subprocess.Popen([sys.executable, script], cwd=app_root)
        except Exception:
            pass
        self.root.destroy()

    def _download_failed(self, error: str) -> None:
        if self._dl_widgets is None:
            return
        _win, _bar, status_lbl, _install_btn, later_btn = self._dl_widgets
        status_lbl.configure(text="Download failed.")
        later_btn.configure(state="normal")
        messagebox.showerror(APP_NAME,
                             f"Could not download the update:\n\n{error}",
                             parent=self.root)

    def _show_up_to_date(self, feed: dict) -> None:
        messagebox.showinfo(
            APP_NAME,
            "You're up to date!\n\n"
            f"Latest version: {feed['version']}\n"
            f"Your version:    {__version__}",
            parent=self.root)

    # -- dynamic labels ----------------------------------------------------

    def _mode_text(self) -> str:
        fast = "Fast" if self.fast_var.get() else "Streamed"
        extra = " · double" if self.double_var.get() else ""
        return f"Current: {fast} · x{self.multiplier_var.get()} · P{self.preset_var.get()}{extra}"

    def _refresh_dynamic(self) -> None:
        if hasattr(self, "customise_tile"):
            self.customise_tile.set_sub(self._mode_text())
        if hasattr(self, "output_hint"):
            ext = ".mid.xz.xz" if self.double_var.get() else ".mid.xz"
            self.output_hint.configure(text=f"(1 – 65,535) · auto-saved as {ext}")
        if not hasattr(self, "track_status_var"):
            return
        if self._running:
            return
        if self._load_pending:
            self.track_status_var.set("Loading file…")
            return
        multiplier = self._multiplier()
        if self.info is not None:
            total_tracks, _total_notes, length, eff = self._plan()
            status = (f"Loading track 0/{total_tracks:,}. "
                      f"Length: {length:,} bytes")
            if eff and eff < multiplier:
                status += f" (×{multiplier:,} capped to ×{eff:,})"
            self.track_status_var.set(status)
        else:
            self.track_status_var.set(f"Ready. Set to x{multiplier:,}.")

    # -- settings persistence ----------------------------------------------

    def _apply_settings(self, skip_validate: bool = False) -> None:
        if self.settings.get("remember_input") and self.settings.get("last_input"):
            path = self.settings["last_input"]
            if os.path.isfile(path):
                self.input_var.set(path)
                if not skip_validate:
                    # Load in the background so startup stays instant even for
                    # a very large remembered track.
                    self.info = None
                    self.track_bytes = 0
                    self._start_background_load(path)
        if self.settings.get("auto_output") and self.settings.get("last_output"):
            self.output_var.set(self.settings["last_output"])
        self.multiplier_var.set(str(self.settings.get("multiplier", 65535)))
        self.theme_var.set(self.settings.get("theme", "dark"))
        self.check_updates_var.set(bool(self.settings.get("check_updates", True)))
        self._refresh_after_file()

    def _show_loading(self, visible: bool) -> None:
        """Show/hide the in-window loading bar (not the generation bar)."""
        if not hasattr(self, "load_progress"):
            return
        if visible:
            self.load_progress.grid()
            self.load_info.grid()
            self.load_progress.start(12)
        else:
            self.load_progress.stop()
            self.load_progress.grid_remove()

    def _start_background_load(self, path: str, manual: bool = False) -> None:
        """Parse a MIDI on a worker thread so the UI never freezes.

        ``manual`` marks a load the user explicitly requested (choosing a
        file), so errors are shown in a dialog rather than just the status
        line.
        """
        self._load_pending = True
        self._load_manual = manual
        self._load_token += 1
        token = self._load_token
        self.track_status_var.set("Loading file…")
        self._show_loading(True)
        self.load_info_var.set("Loading file…")

        def load() -> None:
            _console(f"[Systematics] Loading MIDI: {path}")

            def progress(notes_done: int, tracks_done: int, tracks_total: int) -> None:
                _console(
                    f"\rTrack {tracks_done}/{tracks_total} loaded. "
                    f"Loaded note(s): {notes_done:,}",
                    end="")
                self._load_queue.put(
                    ("loadprogress", token, notes_done, tracks_done, tracks_total))

            try:
                info = midi_engine.load_midi_fast(path, progress_cb=progress)
                ntrks = len(info.track_chunks)
                _console(
                    f"\rTrack {ntrks}/{ntrks} loaded. "
                    f"Loaded note(s): {info.note_count:,} ("
                    f"{midi_engine.human_size(info.input_size)})")
                self._load_queue.put((token, info, ""))
            except midi_engine.MidiError as exc:
                _console(f"\rFailed to load MIDI: {exc}")
                self._load_queue.put((token, None, str(exc)))
            except Exception as exc:  # never let a worker die silently
                _console(f"\rFailed to load MIDI: {exc}")
                self._load_queue.put((token, None, f"Unexpected error: {exc}"))

        threading.Thread(target=load, daemon=True).start()
        self.root.after(100, self._poll_load)

    def _poll_load(self) -> None:
        try:
            msg = self._load_queue.get_nowait()
        except queue.Empty:
            if self._load_pending:
                self.root.after(100, self._poll_load)
            return

        if msg[0] == "loadprogress":
            _kind, token, notes_done, tracks_done, tracks_total = msg
            if token == self._load_token:
                self.load_info_var.set(
                    f"Track {tracks_done}/{tracks_total} loaded. "
                    f"Loaded note(s): {notes_done:,}")
            self.root.after(100, self._poll_load)
            return

        token, info, error = msg
        if token != self._load_token:
            # A newer load started; ignore this stale result but keep polling
            # for the newer load if one is still in flight.
            if self._load_pending:
                self.root.after(100, self._poll_load)
            return
        self._load_pending = False
        self._show_loading(False)
        if info is None:
            self.info = None
            self.track_bytes = 0
            self.load_info_var.set("")
            if hasattr(self, "load_info"):
                self.load_info.grid_remove()
            self.track_status_var.set(error or "Could not load the file.")
            if self._load_manual:
                self._load_manual = False
                messagebox.showerror(
                    APP_NAME, error or "Could not load the file.",
                    parent=self.root)
        else:
            self.info = info
            self.track_bytes = sum(len(c) for c in info.track_chunks)
            self.selected_tracks = self._selection_for(info)
            self._load_manual = False
            ntrks = len(info.track_chunks)
            self.load_info_var.set(
                f"Loaded {info.note_count:,} note(s) · {ntrks} track"
                f"{'s' if ntrks != 1 else ''}")
        self._refresh_after_file()

    def _persist(self) -> None:
        self.settings["last_input"] = self.input_var.get()
        self.settings["last_output"] = self.output_var.get()
        app_settings.save(self.settings)

    # -- file / path helpers ----------------------------------------------

    def choose_input(self) -> None:
        initial = self.input_var.get().strip() or None
        path = filedialog.askopenfilename(
            parent=self.root, title="Choose a 1-track MIDI file",
            initialdir=os.path.dirname(initial) if initial else None,
            filetypes=[("MIDI files", "*.mid *.midi"), ("All files", "*.*")])
        if not path:
            return
        self.input_var.set(path)
        self.info = None
        self.track_bytes = 0
        if self.settings.get("auto_output") and not self.output_var.get().strip():
            self._suggest_output()
        # Load in the background so the window stays responsive even for a
        # huge manually-chosen track.
        self._start_background_load(path, manual=True)
        self._refresh_after_file()

    def choose_output(self) -> None:
        initial = self.output_var.get().strip()
        if not initial and self.input_var.get().strip():
            initial = self._derived_output()
        path = filedialog.asksaveasfilename(
            parent=self.root, title="Save duplicated MIDI as",
            initialdir=os.path.dirname(initial) if initial else None,
            initialfile=os.path.basename(initial) if initial else "MIDIOUT.mid.xz",
            defaultextension=".mid.xz.xz" if self.double_var.get() else ".mid.xz",
            filetypes=[("XZ compressed MIDI", "*.mid.xz *.mid.xz.xz"),
                       ("XZ file", "*.xz"), ("All files", "*.*")])
        if path:
            self.output_var.set(path)
            self._persist()

    def _derived_output(self) -> str:
        source = self.input_var.get().strip()
        if not source:
            return ""
        stem, _ = os.path.splitext(source)
        ext = ".mid.xz.xz" if self.double_var.get() else ".mid.xz"
        return f"{stem}_x{self._multiplier()}{ext}"

    def _suggest_output(self) -> None:
        self.output_var.set(self._derived_output())

    def _multiplier(self) -> int:
        try:
            return int(self.multiplier_var.get())
        except (ValueError, tk.TclError):
            return int(self.settings.get("multiplier", 65535))

    # -- track selection ---------------------------------------------------

    def _selection_for(self, info: midi_engine.MidiInfo) -> list[int]:
        """Restore the stored track selection for a file (default: all tracks)."""
        n = len(info.track_chunks)
        stored = self.settings.get("track_selection", {}).get(info.path)
        if isinstance(stored, list) and stored:
            valid = [i for i in stored if isinstance(i, int) and 0 <= i < n]
            if valid:
                return valid
        return list(range(n))

    def _selected(self) -> list[int]:
        """Return the currently selected (to-multiply) track indices."""
        if self.info is None:
            return []
        n = len(self.info.track_chunks)
        return [i for i in self.selected_tracks if 0 <= i < n]

    def _plan(self) -> tuple:
        """Plan for the current file/selection (empty when no file loaded)."""
        if self.info is None:
            return (0, 0, 0, 0)
        return midi_engine.plan_build(self.info, self._multiplier(),
                                      self._selected())

    def _set_track_selected(self, index: int, selected: bool) -> None:
        """Toggle one track's multiply flag, persist, and refresh the UI."""
        if self.info is None:
            return
        n = len(self.info.track_chunks)
        current = set(self._selected())
        if selected:
            current.add(index)
        else:
            current.discard(index)
        self.selected_tracks = [i for i in range(n) if i in current]
        selection = self.settings.setdefault("track_selection", {})
        selection[self.info.path] = list(self.selected_tracks)
        self._persist()
        self._refresh_after_file()

    def _refresh_after_file(self) -> None:
        self._redraw_card()
        name = os.path.basename(self.input_var.get()) if self.input_var.get() else "None"
        self.file_status_var.set(f"Currently chosen file: {name}")
        self._refresh_dynamic()

    # -- file properties ---------------------------------------------------

    def show_file_properties(self) -> None:
        if self.info is None:
            messagebox.showinfo(
                APP_NAME,
                "No file chosen yet.\n\nClick the document in the middle to "
                "choose a MIDI file.",
                parent=self.root)
            return

        p = PALETTE
        window = tk.Toplevel(self.root)
        window.title(f"File properties — {APP_NAME}")
        window.configure(bg=p["MAIN_BG"])
        window.resizable(False, False)
        window.transient(self.root)
        self._apply_dialog_titlebar(window)

        frame = tk.Frame(window, bg=p["MAIN_BG"], padx=20, pady=18)
        frame.pack(fill="both", expand=True)

        info = self.info
        row = 0
        for label, value in (
            ("File", os.path.basename(self.input_var.get())),
            ("Path", self.input_var.get()),
            ("Size", f"{midi_engine.human_size(info.input_size)} ({info.input_size:,} bytes)"),
            ("Format", f"Type {info.format}"),
            ("Tracks", str(len(info.track_chunks))),
            ("Notes", f"{info.note_count:,}"),
            ("Loader", getattr(info, "loader", "standard") or "standard"),
            ("Memory (in RAM)",
             f"{midi_engine.human_size(self.track_bytes)} ({self.track_bytes:,} bytes)"),
            ("End of track", "yes" if info.end_of_track else "no"),
        ):
            tk.Label(frame, text=label + ":", bg=p["MAIN_BG"], fg=p["TEXT_MUTED"],
                     font=_font(9)).grid(row=row, column=0, sticky="nw", pady=2)
            tk.Label(frame, text=value, bg=p["MAIN_BG"], fg=p["TEXT"], font=_font(9),
                     wraplength=360, justify="left").grid(
                row=row, column=1, sticky="nw", padx=(14, 0), pady=2)
            row += 1

        # Track selection (multi-track support).
        n = len(info.track_chunks)
        tk.Label(frame,
                 text=f"Tracks to multiply (repeat ×{self._multiplier():,}):",
                 bg=p["MAIN_BG"], fg=p["ACCENT"], font=_font(10, "bold")).grid(
            row=row, column=0, columnspan=3, sticky="w", pady=(12, 4))
        row += 1
        selected = set(self._selected())
        for i in range(n):
            var = tk.BooleanVar(value=i in selected)
            notes = info.track_note_counts[i] if i < len(info.track_note_counts) else 0
            name = info.track_names[i] if i < len(info.track_names) else ""
            label_text = f"Track {i + 1} — {notes:,} notes"
            if name:
                label_text += f" ({name})"
            ttk.Checkbutton(
                frame, text=label_text, variable=var,
                command=lambda idx=i, v=var: self._set_track_selected(idx, v.get())
            ).grid(row=row, column=0, columnspan=3, sticky="w", pady=2)
            row += 1

        sep = tk.Frame(frame, bg=p["CARD_BORDER"], height=1)
        sep.grid(row=row, column=0, columnspan=3, sticky="ew", pady=12)
        row += 1

        tk.Label(frame, text="Output:", bg=p["MAIN_BG"], fg=p["TEXT_MUTED"],
                 font=_font(9)).grid(row=row, column=0, sticky="w", pady=2)
        out_entry = tk.Entry(frame, textvariable=self.output_var, width=44,
                             bg=p["FIELD"], fg=p["TEXT"], insertbackground=p["TEXT"],
                             relief="flat")
        out_entry.grid(row=row, column=1, sticky="ew", padx=(14, 0), pady=2)
        tk.Button(frame, text="Choose…", command=self.choose_output,
                  bg=p["BUTTON_SECONDARY"], fg=p["TEXT"],
                  activebackground=p["BUTTON_SECONDARY_HOVER"],
                  activeforeground=p["TEXT"], relief="flat", padx=10, pady=2,
                  font=_font(9), cursor="hand2").grid(
            row=row, column=2, sticky="w", padx=(8, 0), pady=2)
        row += 1

        tk.Button(frame, text="Close", command=window.destroy, bg=p["ACCENT"],
                  fg=p["ACCENT_ON"], activebackground=p["ACCENT_HOVER"],
                  activeforeground=p["ACCENT_ON"], relief="flat", padx=18,
                  pady=6, font=_font(9, "bold"), cursor="hand2").grid(
            row=row, column=0, columnspan=3, sticky="e", pady=(16, 0))

        window.grab_set()

    # -- run lifecycle -----------------------------------------------------

    def start_generate(self) -> None:
        if self._running:
            return
        if self._load_pending:
            messagebox.showinfo(
                APP_NAME,
                "The file is still loading. Please wait a moment and press Start again.",
                parent=self.root)
            return
        if self.info is None or not os.path.isfile(self.input_var.get()):
            messagebox.showerror(
                APP_NAME,
                "Choose a MIDI file first (click the document in the middle).",
                parent=self.root)
            return

        try:
            multiplier = int(self.multiplier_var.get())
        except (ValueError, tk.TclError):
            messagebox.showerror(
                APP_NAME, "Multiplier must be a whole number between 1 and 65535.",
                parent=self.root)
            return
        if not 1 <= multiplier <= 65535:
            messagebox.showerror(
                APP_NAME, "Multiplier must be between 1 and 65535.", parent=self.root)
            return

        input_path = self.input_var.get()
        output_path = self.output_var.get().strip().strip('"')
        if not output_path:
            output_path = self._derived_output() or "MIDIOUT.mid.xz"
            self.output_var.set(output_path)

        if os.path.abspath(output_path) == os.path.abspath(input_path):
            messagebox.showerror(
                APP_NAME, "Output path must be different from the input file.",
                parent=self.root)
            return
        if os.path.exists(output_path):
            if not messagebox.askyesno(
                    APP_NAME,
                    f"{output_path}\n\nalready exists. Overwrite it?",
                    parent=self.root):
                return

        try:
            preset = int(self.preset_var.get())
        except (ValueError, tk.TclError):
            preset = int(self.settings.get("compression_preset", 6))
        fast = bool(self.fast_var.get())
        double = bool(self.double_var.get())

        selected = self._selected()
        if not selected:
            messagebox.showerror(
                APP_NAME,
                "Select at least one track to multiply "
                "(File properties → tracks).",
                parent=self.root)
            return

        total_tracks, _total_notes, length, eff = midi_engine.plan_build(
            self.info, multiplier, selected)
        if eff < multiplier:
            messagebox.showinfo(
                APP_NAME,
                f"The requested multiplier (×{multiplier:,}) would produce "
                f"more than 65,535 tracks.\n\n"
                f"It was capped to ×{eff:,} so the output has "
                f"{total_tracks:,} tracks total.",
                parent=self.root)

        self._persist()
        self._set_running(True)
        self.progress.configure(maximum=total_tracks, value=0)
        self._run_uncompressed = length
        self.track_status_var.set(
            f"Loading track 0/{total_tracks:,}. Length: {length:,} bytes")

        self._cancel = threading.Event()
        info = self.info  # already parsed & held in memory; skip re-reading
        self._thread = threading.Thread(
            target=self._worker,
            args=(input_path, output_path, multiplier, preset, fast, double,
                  info, selected),
            daemon=True)
        self._thread.start()
        self.root.after(60, self._poll)

    def _worker(self, input_path: str, output_path: str, multiplier: int,
                preset: int, fast: bool, double: bool,
                info: midi_engine.MidiInfo | None,
                multiply_tracks: list[int]) -> None:
        def progress(done: int, total: int, notes_done: int,
                     bytes_done: int) -> None:
            self._queue.put(("progress", done, total, notes_done, bytes_done))

        def progress2(done: int, total: int) -> None:
            self._queue.put(("progress2", done, total))

        try:
            result = midi_engine.build_duplicated_xz(
                input_path, output_path, multiplier,
                preset=preset, fast=fast, double_compress=double,
                progress_cb=progress, progress2_cb=progress2,
                cancel_event=self._cancel, info=info,
                multiply_tracks=multiply_tracks)
            self._queue.put(("done", result))
        except midi_engine.Cancelled:
            self._queue.put(("cancelled", output_path))
        except midi_engine.MidiError as exc:
            self._queue.put(("error", str(exc), output_path))
        except Exception as exc:  # never let a worker thread die silently
            self._queue.put(("error", f"Unexpected error: {exc}", output_path))

    def _poll(self) -> None:
        try:
            while True:
                message = self._queue.get_nowait()
                kind = message[0]
                if kind == "progress":
                    _, done, total, notes_done, bytes_done = message
                    self.progress.configure(value=done)
                    speed = ""
                    elapsed = time.perf_counter() - self._run_started
                    if elapsed > 0.05:
                        speed = (" · Programme speed: "
                                 f"{self._speed_text(notes_done, bytes_done, elapsed)}")
                    self.track_status_var.set(
                        f"Loading track {done:,}/{total:,}. "
                        f"Length: {self._run_uncompressed:,} bytes{speed}")
                elif kind == "progress2":
                    _, done, total = message
                    self.track_status_var.set(
                        f"Second pass… {done:,} / {total:,} bytes")
                elif kind == "done":
                    self._finish(message[1])
                elif kind == "cancelled":
                    self._cancelled(message[1])
                elif kind == "error":
                    self._failed(message[1], message[2])
        except queue.Empty:
            pass
        if self._running:
            self.root.after(60, self._poll)

    def _speed_text(self, notes: int, bytes_: int, elapsed: float) -> str:
        """Format a processing-speed summary like the reference app's log."""
        if elapsed <= 0:
            return ""
        nps = notes / elapsed
        mbps = bytes_ / elapsed / (1024 * 1024)
        return f"{nps:,.0f} notes/s ({mbps:.1f} MB/s)"

    def _finish(self, result: midi_engine.BuildResult) -> None:
        self._set_running(False)
        self.progress.configure(value=result.track_count)
        ext = ".xz.xz" if result.double_compress else ".xz"
        self.track_status_var.set(
            f"Done. {result.uncompressed_size:,} bytes MIDI → "
            f"{result.compressed_size:,} bytes {ext}")
        self.settings["last_output"] = result.output_path
        self._persist()
        avg_speed = self._speed_text(result.total_notes,
                                     result.uncompressed_size, result.elapsed)
        lines = [
            "Duplication complete!",
            "",
            f"Tracks:          {result.track_count:,}",
        ]
        if result.effective_multiplier and \
                result.effective_multiplier != result.multiplier:
            lines.append(
                f"Multiplier:      ×{result.effective_multiplier:,} "
                f"(capped from ×{result.multiplier:,})")
        else:
            lines.append(f"Multiplier:      ×{result.multiplier:,}")
        if 0 < len(result.selected_tracks) < len(result.per_track_notes):
            sel = ", ".join(str(i + 1) for i in result.selected_tracks)
            lines.append(f"Multiplied:      track {sel}")
        lines += [
            f"Total notes:     {result.total_notes:,}",
            f"Uncompressed:    {midi_engine.human_size(result.uncompressed_size)}",
            f"Compressed:      {midi_engine.human_size(result.compressed_size)}",
            f"Double pass:     {'yes' if result.double_compress else 'no'}",
            f"Elapsed:         {result.elapsed:.2f}s",
            f"Avg. speed:      {avg_speed}",
            "",
            "Saved to:",
            result.output_path,
        ]
        messagebox.showinfo(APP_NAME, "\n".join(lines), parent=self.root)

    def _cancelled(self, output_path: str) -> None:
        self._set_running(False)
        self.track_status_var.set("Cancelled.")
        _remove_partial(output_path)

    def _failed(self, message: str, output_path: str) -> None:
        self._set_running(False)
        self.track_status_var.set("Failed.")
        _remove_partial(output_path)
        messagebox.showerror(APP_NAME, message, parent=self.root)

    def request_cancel(self) -> None:
        if self._running:
            self._cancel.set()
            self.track_status_var.set("Cancelling…")

    def _set_running(self, running: bool) -> None:
        self._running = running
        if running:
            self._run_started = time.perf_counter()
        self.start_tile.set_enabled(not running)
        self.interrupt_tile.set_enabled(running)
        if not running:
            self._refresh_dynamic()

    # -- icon / close ------------------------------------------------------

    def _load_icon(self) -> None:
        icon_dir = os.path.dirname(os.path.abspath(__file__))
        if os.name == "nt":
            # Windows taskbar: needs a real .ico and an explicit AppUserModelID,
            # otherwise the shell shows python.exe's icon instead of ours.
            _set_app_user_model_id("SystematicsTRILLIONMIDImaker.1.0")
            ico_path = os.path.join(icon_dir, "icon.ico")
            if os.path.isfile(ico_path):
                try:
                    self.root.iconbitmap(default=ico_path)
                    return
                except tk.TclError:
                    pass
        icon_path = os.path.join(icon_dir, "icon.png")
        if os.path.isfile(icon_path):
            try:
                self._icon = tk.PhotoImage(file=icon_path)
                self.root.iconphoto(True, self._icon)
            except tk.TclError:
                self._icon = None

    def _on_close(self) -> None:
        if self._running and not messagebox.askyesno(
                APP_NAME, "A duplication is still running. Quit anyway?",
                parent=self.root):
            return
        if self._running:
            self._cancel.set()
        self._persist()
        self.root.destroy()

    def _apply_dialog_titlebar(self, window: tk.Toplevel) -> None:
        """Match a popup window's title bar to the active theme."""
        _enable_dark_titlebar(window, self._theme_name == "dark")


def _remove_partial(path: str) -> None:
    """Delete a partial/corrupt output file after a failed run."""
    try:
        if path and os.path.isfile(path):
            os.remove(path)
    except OSError:
        pass


def _set_app_user_model_id(app_id: str) -> None:
    """Give the process an explicit Windows AppUserModelID.

    Without this, Windows groups the window under the Python interpreter and
    shows python.exe's icon on the taskbar instead of the app's icon.
    """
    if os.name != "nt":
        return
    try:
        import ctypes
        ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID(app_id)
    except Exception:
        pass


def _enable_dark_titlebar(root: tk.Tk, dark: bool = True) -> None:
    """Ask Windows to render this window's title bar dark (or light)."""
    if os.name != "nt":
        return
    try:
        import ctypes

        user32 = ctypes.WinDLL("user32")
        dwmapi = ctypes.WinDLL("dwmapi")
        user32.GetParent.restype = ctypes.c_void_p
        user32.GetParent.argtypes = [ctypes.c_void_p]
        dwmapi.DwmSetWindowAttribute.restype = ctypes.c_long
        dwmapi.DwmSetWindowAttribute.argtypes = [
            ctypes.c_void_p, ctypes.c_uint, ctypes.c_void_p, ctypes.c_uint]

        root.update_idletasks()
        hwnd = user32.GetParent(ctypes.c_void_p(root.winfo_id()))
        enabled = ctypes.c_int(1 if dark else 0)
        # DWMWA_USE_IMMERSIVE_DARK_MODE is 20 on Win10 20H1+, 19 before that.
        for attribute in (20, 19):
            if dwmapi.DwmSetWindowAttribute(
                    hwnd, attribute, ctypes.byref(enabled),
                    ctypes.sizeof(enabled)) == 0:
                break
    except Exception:
        pass


def main() -> None:
    root = tk.Tk()
    App(root)
    root.mainloop()


if __name__ == "__main__":
    main()
