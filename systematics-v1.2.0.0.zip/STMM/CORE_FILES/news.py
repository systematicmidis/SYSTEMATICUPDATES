"""News / announcements feed for Systematics TRILLION MIDI maker.

The app polls a tiny JSON "feed" hosted on GitHub Pages (or anywhere that
serves plain HTTP/HTTPS) and shows the latest headline in a ticker bar at the
bottom of the window, with a "More News" window listing every article.

Feed format::

    {
      "articles": [
        {
          "id": "v1.2.0.0",                       # optional, shown nowhere (kept for tools)
          "title": "Systematics TRILLION MIDI maker v1.2.0.0",
          "date": "2026-08-17",                   # optional
          "summary": "One short line for the ticker.",
          "body": "Longer text. Separate paragraphs with blank lines.",
          "url": "https://example.com/read-more"  # optional
        }
      ]
    }

Only ``title`` is required. When ``summary`` is missing the first line of
``body`` is used, and when ``body`` is missing the ``summary`` is used. A bare
JSON array of article objects is also accepted.
"""

from __future__ import annotations

import json
import urllib.request

DEFAULT_TIMEOUT = 10

# The built-in news feed. Point this at your own hosted news.json to publish
# announcements to everyone running the app.
DEFAULT_NEWS_URL = "https://systematicmidis.github.io/news.json"


class NewsError(Exception):
    """Raised when the news feed can't be fetched or is malformed."""


def fetch_news(url: str = DEFAULT_NEWS_URL, timeout: int = DEFAULT_TIMEOUT) -> list[dict]:
    """Download and parse the news feed into a list of article dicts.

    Each article dict has the keys ``id``, ``title``, ``date``, ``summary``,
    ``body`` and ``url``. Returns ``[]`` when the URL is empty (feature
    disabled). Raises :class:`NewsError` when the feed can't be fetched or is
    malformed.
    """
    url = (url or "").strip()
    if not url:
        return []
    if not (url.startswith("http://") or url.startswith("https://")):
        raise NewsError("News URL must start with http:// or https://")
    try:
        with urllib.request.urlopen(url, timeout=timeout) as resp:
            raw = resp.read().decode("utf-8", errors="replace")
        data = json.loads(raw)
    except Exception as exc:
        raise NewsError(f"Could not fetch the news feed: {exc}") from exc

    if isinstance(data, dict):
        items = data.get("articles", data.get("news", []))
    elif isinstance(data, list):
        items = data
    else:
        raise NewsError("News feed must be a JSON object with an 'articles' list "
                        "or a JSON array.")

    if not isinstance(items, list):
        raise NewsError("News feed 'articles' must be a list.")

    articles: list[dict] = []
    for item in items:
        if not isinstance(item, dict):
            continue
        title = str(item.get("title", "")).strip()
        if not title:
            continue
        summary = str(item.get("summary", "")).strip()
        body = str(item.get("body", "")).strip()
        if not body:
            body = summary
        if not summary:
            summary = body.split("\n", 1)[0].strip() if body else title
        if not body:
            body = summary
        articles.append({
            "id": str(item.get("id", "")).strip(),
            "title": title,
            "date": str(item.get("date", "")).strip(),
            "summary": summary,
            "body": body,
            "url": str(item.get("url", "")).strip(),
        })
    return articles
