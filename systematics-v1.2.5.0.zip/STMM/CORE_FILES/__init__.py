"""CORE_FILES — the important Python files for Systematics TRILLION MIDI maker.

This package holds the application's real logic so the top-level launcher
(``trillion.py``) stays tiny:

* ``midi_engine`` — MIDI parsing, validation and XZ duplication.
* ``settings``   — persistent user preferences.
* ``updater``    — checks a hosted JSON feed for newer versions.
* ``news``       — fetches the hosted announcements feed.
* ``app``        — the tkinter desktop UI (menus, dialogs, progress).
* ``icon.png``   — the application icon used by the window.
"""

__version__ = "1.2.5.0"
APP_NAME = "Systematics TRILLION MIDI maker"
