"""MIDI parsing, validation and XZ duplication for Systematics TRILLION MIDI maker.

The idea (taken from the original ``trillion.py`` example, then hardened):

* Accept a MIDI file and pick which track(s) get multiplied.
* Rewrite the header so the track count reflects the new layout.
* Repeat each selected track chunk ``multiplier`` times (unselected tracks
  are kept once, e.g. a melody track next to a duplicated "spam" track).
* Store the result inside a single ``.xz`` stream so the (potentially huge)
  uncompressed MIDI takes almost no disk space.

Two write strategies are provided:

* **streamed** (default) — one continuous XZ stream; LZMA sees the repeated
  track and produces the smallest possible file.
* **fast** — the track is compressed once and that one compressed block is
  written repeatedly (concatenated XZ streams). Nearly instant, but larger.
"""

from __future__ import annotations

import heapq
import io
import lzma
import os
import tempfile
import time
from dataclasses import dataclass

MIN_TRACKS = 1
MAX_TRACKS = 65535  # the MIDI track-count field is an unsigned 16-bit value
MAX_TRACK_BYTES = 0xFFFFFFFF  # the MTrk length field is an unsigned 32-bit value (~4 GB)

# Note-count tiers the loaders are sized for. The dispatcher can't know the
# exact note count without scanning the file, so it estimates it from the
# file size using ESTIMATED_BYTES_PER_NOTE below.
LARGE_NOTES = 10_000_000    # more than this many notes -> Large MIDI Loader
MEGA_NOTES = 100_000_000    # more than this many notes -> Mega MIDI Loader

# Typical black-MIDI files use ~6-10 bytes per note (the reference 164 MB /
# 21.5M-note track is ~7.6). Use a conservative lower bound so files "above N
# notes" reliably reach the right tier.
ESTIMATED_BYTES_PER_NOTE = 5

LARGE_THRESHOLD = LARGE_NOTES * ESTIMATED_BYTES_PER_NOTE   # ~50 MB -> Large
MEGA_THRESHOLD = MEGA_NOTES * ESTIMATED_BYTES_PER_NOTE     # ~500 MB -> Mega

# RAM preload modes: how many copies of the input file are held in memory
# after loading (normal = the parsed track chunks only, roughly 1x the file;
# double = chunks + the raw file bytes; triple = + a joined copy of the
# chunks). The user picks a mode and an optional cap in MB.
RAM_MODES = {"normal": 1, "double": 2, "triple": 3}
RAM_MODE_LABELS = {
    "normal": "Normal (1×)",
    "double": "Double (2×)",
    "triple": "Triple (3×)",
}

# Note-merge speed tiers. The dominant cost of ``build_note_multiplied_xz``
# used to be calling ``LZMACompressor.compress`` once per ~5-byte event; we
# now buffer events into a bytearray and compress in bulk. ``preset_max``
# also clamps the LZMA preset downward (lower preset = much faster but larger
# output), and ``buffer`` is how many bytes of merged track are accumulated
# before one compress() call.
MERGE_SPEEDS = {
    "balanced": {"preset_max": 9, "buffer": 1 << 20},   # 1 MiB
    "fast":     {"preset_max": 1, "buffer": 1 << 22},   # 4 MiB
    "turbo":    {"preset_max": 0, "buffer": 1 << 24},   # 16 MiB
}

MIDI_FORMATS = (0, 1)
CHUNK_HEADER = b"MThd"
CHUNK_TRACK = b"MTrk"


class MidiError(Exception):
    """Raised when the input MIDI is missing, malformed or not single-track."""


class Cancelled(Exception):
    """Raised inside a build when the user cancels the operation."""


@dataclass
class MidiInfo:
    """Everything the engine needs to know about a validated input MIDI."""

    path: str
    format: int
    ntrks: int
    division: bytes          # the 2-byte "division" field from the header
    track_chunks: list       # raw "MTrk" chunks (id + length + data)
    note_count: int          # note-on events (velocity > 0), all tracks
    end_of_track: bool       # whether an End-of-Track meta event was seen
    input_size: int          # size of the input file in bytes
    track_note_counts: list  # note-on count for each track chunk
    track_names: list  # track-name meta (0x03) per chunk, or ""
    loader: str = "standard"  # which loader produced this info
    ram_mode: int = 1          # effective preload multiplier (1, 2 or 3)
    ram_capped: bool = False   # True when max_ram_mb forced a lower mode
    max_ram_mb: int = 0        # the cap applied at load time (0 = none)
    raw_data: bytes | None = None    # retained 2nd copy (double/triple)
    linked_data: bytes | None = None  # retained 3rd copy (triple only)


@dataclass
class BuildResult:
    """Summary of a finished duplication run."""

    output_path: str
    multiplier: int
    track_count: int          # total track chunks written
    total_notes: int          # note-on events across every written track
    input_size: int
    uncompressed_size: int
    compressed_size: int
    elapsed: float
    fast_mode: bool
    double_compress: bool = False
    selected_tracks: tuple = ()   # indices that were multiplied
    per_track_notes: tuple = ()   # note count of each source track
    effective_multiplier: int = 0  # multiplier after capping to 65,535 tracks
    note_mode: bool = False        # True when notes (not tracks) were multiplied


# --------------------------------------------------------------------------
# Low level MIDI helpers
# --------------------------------------------------------------------------

def _decode_name(raw: bytes) -> str:
    """Turn raw track-name meta bytes into a display string (best effort)."""
    text = raw.decode("utf-8", errors="replace")
    return text.strip("\x00 \t\r\n") or ""


def _read_vlq(data: bytes, i: int) -> tuple[int, int]:
    """Read a MIDI variable-length quantity starting at ``i``.

    Returns ``(value, next_index)``.
    """
    value = 0
    n = len(data)
    for _ in range(4):  # MIDI VLQs are at most 4 bytes
        if i >= n:
            raise MidiError("Truncated variable-length value in MIDI track.")
        byte = data[i]
        i += 1
        value = (value << 7) | (byte & 0x7F)
        if not byte & 0x80:
            return value, i
    raise MidiError("Invalid variable-length value in MIDI track.")


def _scan_track(track_data: bytes) -> tuple[int, bool, str]:
    """Walk a track's events, counting note-ons and checking structure.

    Returns ``(note_count, has_end_of_track, track_name)``. Raises
    :class:`MidiError` for structurally broken tracks.
    """
    i = 0
    n = len(track_data)
    running_status: int | None = None
    note_count = 0
    end_of_track = False
    track_name = ""

    while i < n:
        # Delta time (ignored here, only validated).
        _, i = _read_vlq(track_data, i)
        if i >= n:
            raise MidiError("MIDI track ends in the middle of an event.")

        first = track_data[i]

        if first == 0xFF:  # meta event
            if i + 1 >= n:
                raise MidiError("Truncated MIDI meta event.")
            meta_type = track_data[i + 1]
            i += 2
            length, i = _read_vlq(track_data, i)
            if i + length > n:
                raise MidiError("Truncated MIDI meta event data.")
            if meta_type == 0x2F and length == 0:
                end_of_track = True
            elif meta_type == 0x03 and not track_name:
                track_name = _decode_name(track_data[i:i + length])
            i += length

        elif first in (0xF0, 0xF7):  # SysEx event
            i += 1
            length, i = _read_vlq(track_data, i)
            if i + length > n:
                raise MidiError("Truncated MIDI SysEx event.")
            i += length

        else:
            # Channel (voice) message, possibly using running status.
            if first & 0x80:
                status = first
                running_status = status
                i += 1
            else:
                if running_status is None:
                    raise MidiError("Running status used before any status byte.")
                status = running_status

            high = status & 0xF0
            if high in (0x80, 0x90, 0xA0, 0xB0, 0xE0):  # two data bytes
                if i + 2 > n:
                    raise MidiError("Truncated MIDI channel message.")
                data1 = track_data[i]
                data2 = track_data[i + 1]
                i += 2
                if high == 0x90 and (data2 & 0x7F) > 0:
                    note_count += 1
            elif high in (0xC0, 0xD0):  # one data byte
                if i + 1 > n:
                    raise MidiError("Truncated MIDI channel message.")
                i += 1
            else:
                raise MidiError(f"Invalid MIDI status byte 0x{status:02X}.")

    return note_count, end_of_track, track_name


def _encode_vlq(value: int) -> bytes:
    """Encode a non-negative integer as a MIDI variable-length quantity."""
    value = max(0, int(value))
    buffer = bytearray([value & 0x7F])
    value >>= 7
    while value:
        buffer.append(0x80 | (value & 0x7F))
        value >>= 7
    buffer.reverse()
    return bytes(buffer)


# Event kinds returned by ``_decode_track``.
KIND_NOTE_ON = 0    # note-on with velocity > 0 (counts as a "note")
KIND_NOTE_OFF = 1   # note-off, or note-on with velocity 0
KIND_EOT = 2        # End-of-Track meta event
KIND_OTHER = 3      # any other channel message / meta / SysEx event


def _iter_track_events(track_data: bytes):
    """Yield ``(delta_ticks, raw_event, kind)`` triples lazily.

    Streaming equivalent of :func:`_decode_track`: running-status channel
    messages are emitted in explicit form (status byte included) so every
    event is self-contained and can be re-timed when notes are
    merged/multiplied. The raw bytes never include the delta time. Decoding
    lazily (instead of building a list) keeps huge black-MIDI tracks from
    ballooning in memory during note multiplication.
    """
    i = 0
    n = len(track_data)
    running_status: int | None = None

    while i < n:
        delta, i = _read_vlq(track_data, i)
        if i >= n:
            raise MidiError("MIDI track ends in the middle of an event.")

        first = track_data[i]

        if first == 0xFF:  # meta event
            if i + 1 >= n:
                raise MidiError("Truncated MIDI meta event.")
            meta_type = track_data[i + 1]
            length, j = _read_vlq(track_data, i + 2)
            if j + length > n:
                raise MidiError("Truncated MIDI meta event data.")
            raw = track_data[i:j + length]
            kind = KIND_EOT if (meta_type == 0x2F and length == 0) else KIND_OTHER
            yield delta, raw, kind
            i = j + length

        elif first in (0xF0, 0xF7):  # SysEx event
            length, j = _read_vlq(track_data, i + 1)
            if j + length > n:
                raise MidiError("Truncated MIDI SysEx event.")
            yield delta, track_data[i:j + length], KIND_OTHER
            i = j + length

        else:
            # Channel (voice) message, possibly using running status.
            if first & 0x80:
                status = first
                running_status = status
                i += 1
            else:
                if running_status is None:
                    raise MidiError("Running status used before any status byte.")
                status = running_status

            high = status & 0xF0
            if high in (0x80, 0x90, 0xA0, 0xB0, 0xE0):  # two data bytes
                if i + 2 > n:
                    raise MidiError("Truncated MIDI channel message.")
                data1 = track_data[i]
                data2 = track_data[i + 1]
                i += 2
                raw = bytes([status, data1, data2])
                if high == 0x90:
                    kind = KIND_NOTE_ON if (data2 & 0x7F) > 0 else KIND_NOTE_OFF
                elif high == 0x80:
                    kind = KIND_NOTE_OFF
                else:
                    kind = KIND_OTHER
                yield delta, raw, kind
            elif high in (0xC0, 0xD0):  # one data byte
                if i + 1 > n:
                    raise MidiError("Truncated MIDI channel message.")
                raw = bytes([status, track_data[i]])
                i += 1
                yield delta, raw, KIND_OTHER
            else:
                raise MidiError(f"Invalid MIDI status byte 0x{status:02X}.")


def _decode_track(track_data: bytes) -> list[tuple[int, bytes, int]]:
    """Decode a track into ``(delta_ticks, raw_event, kind)`` triples.

    Kept as a convenience wrapper around :func:`_iter_track_events`; streaming
    callers should use the iterator directly to avoid materializing a list.
    """
    return list(_iter_track_events(track_data))


# --------------------------------------------------------------------------
# Parsing / validation
# --------------------------------------------------------------------------

def parse_midi(path: str) -> MidiInfo:
    """Read a MIDI file and return its structure without enforcing track count."""
    if not os.path.isfile(path):
        raise MidiError(f"File not found: {path}")

    with open(path, "rb") as f:
        magic = f.read(4)
        if magic != CHUNK_HEADER:
            raise MidiError("Not a standard MIDI file (missing 'MThd' header).")

        header_len = int.from_bytes(f.read(4), "big")
        if header_len < 6:
            raise MidiError("Invalid MIDI header (length < 6).")
        header = f.read(header_len)
        if len(header) != header_len:
            raise MidiError("Truncated MIDI header.")

        fmt = int.from_bytes(header[0:2], "big")
        ntrks = int.from_bytes(header[2:4], "big")
        division = header[4:6]

        track_chunks: list[bytes] = []
        track_note_counts: list[int] = []
        track_names: list[str] = []
        note_count = 0
        end_of_track = False
        while True:
            chunk_id = f.read(4)
            if chunk_id == b"":
                break
            if chunk_id != CHUNK_TRACK:
                raise MidiError(
                    f"Unexpected chunk {chunk_id!r} in MIDI file (expected {CHUNK_TRACK!r})."
                )
            track_len = int.from_bytes(f.read(4), "big")
            track_data = f.read(track_len)
            if len(track_data) != track_len:
                raise MidiError("Truncated MIDI track data.")
            track_chunks.append(
                CHUNK_TRACK + int.to_bytes(track_len, 4, "big") + track_data
            )
            notes, eot, name = _scan_track(track_data)
            note_count += notes
            end_of_track = end_of_track or eot
            track_note_counts.append(notes)
            track_names.append(name)

    return MidiInfo(
        path=path,
        format=fmt,
        ntrks=ntrks,
        division=division,
        track_chunks=track_chunks,
        note_count=note_count,
        end_of_track=end_of_track,
        input_size=os.path.getsize(path),
        track_note_counts=track_note_counts,
        track_names=track_names,
    )


def _validate_info(info: MidiInfo) -> MidiInfo:
    """Apply the multi-track rules: a valid format and at least one note."""
    if info.format not in MIDI_FORMATS:
        raise MidiError(f"Unsupported MIDI format {info.format} (expected 0 or 1).")

    if max(info.ntrks, len(info.track_chunks)) < 1:
        raise MidiError("The file contains no tracks.")

    if info.note_count == 0:
        raise MidiError("The file contains no note events.")

    return info


def validate_single_track(path: str) -> MidiInfo:
    """Parse ``path`` and require a well-formed MIDI with exactly one note track."""
    info = _validate_info(parse_midi(path))
    actual = max(info.ntrks, len(info.track_chunks))
    if actual != 1:
        raise MidiError(
            f"This file has {actual} tracks. "
            "Systematics TRILLION MIDI maker needs exactly 1 track."
        )
    return info


def validate_multi_track(path: str) -> MidiInfo:
    """Parse ``path`` and require a well-formed MIDI with at least one note track."""
    return _validate_info(parse_midi(path))


def resolve_ram_mode(ram_mode: str, max_ram_mb: int, file_size: int) -> tuple[int, bool]:
    """Return ``(effective_multiplier, capped)`` for a file of ``file_size`` bytes.

    ``ram_mode`` is one of :data:`RAM_MODES` keys. ``max_ram_mb`` (0 =
    unlimited) caps the multiplier so the estimated footprint (file size ×
    multiplier) stays under the budget; the result is never below 1, so a
    file that already exceeds the cap still loads at 1× but is flagged as
    capped.
    """
    target = RAM_MODES.get(ram_mode, 1)
    if not max_ram_mb or max_ram_mb <= 0 or file_size <= 0:
        return target, False
    max_bytes = max_ram_mb * 1024 * 1024
    effective = max(1, min(target, max_bytes // file_size))
    return effective, effective < target


def _apply_ram_mode(info: MidiInfo, effective: int, capped: bool,
                    max_ram_mb: int) -> MidiInfo:
    """Retain extra in-memory copies of the file per the effective RAM mode.

    Double keeps the raw file bytes; triple additionally keeps a joined copy
    of every track chunk. These are real allocations, so the app's footprint
    genuinely scales with the chosen mode (the memory is held, not paged).
    """
    info.ram_mode = effective
    info.ram_capped = bool(capped)
    info.max_ram_mb = int(max_ram_mb or 0)
    if effective >= 2 and info.raw_data is None:
        try:
            with open(info.path, "rb") as f:
                info.raw_data = f.read()
        except OSError:
            info.raw_data = None
    if effective >= 3 and info.linked_data is None:
        info.linked_data = b"".join(info.track_chunks)
    return info


def ram_footprint(info: MidiInfo) -> int:
    """Approximate bytes the app holds in RAM for a loaded ``info``."""
    base = sum(len(c) for c in info.track_chunks)
    extra = 0
    if getattr(info, "ram_mode", 1) >= 2 and info.raw_data is not None:
        extra += len(info.raw_data)
    if getattr(info, "ram_mode", 1) >= 3 and info.linked_data is not None:
        extra += len(info.linked_data)
    return base + extra


def load_midi_fast(path: str, progress_cb=None, ram_mode: str = "normal",
                   max_ram_mb: int = 0) -> MidiInfo:
    """Load + validate a MIDI with the fastest appropriate loader.

    Tiers are note-based: files above :data:`LARGE_NOTES` notes use the Large
    MIDI Loader and files above :data:`MEGA_NOTES` notes use the memory-mapped
    Mega MIDI Loader; smaller files use the default parser. Because the note
    count isn't known until the file is scanned, the dispatcher estimates it
    from the file size (``ESTIMATED_BYTES_PER_NOTE`` bytes per note). Always
    returns a validated multi-track :class:`MidiInfo`, raising
    :class:`MidiError` otherwise.

    ``ram_mode`` selects how many copies of the file stay in memory (see
    :data:`RAM_MODES`); ``max_ram_mb`` (0 = unlimited) caps the effective
    mode so the footprint never exceeds the budget. Preloading needs a real
    byte buffer, so the memory-mapped Mega loader is only used when the
    effective mode is 1×.

    ``progress_cb(notes_done, tracks_done, tracks_total)`` is forwarded to the
    fast loaders (the small-file path completes too quickly to report).
    """
    size = os.path.getsize(path) if os.path.isfile(path) else 0
    effective, capped = resolve_ram_mode(ram_mode, max_ram_mb, size)

    if size < LARGE_THRESHOLD and effective <= 1:
        info = validate_multi_track(path)
    else:
        from . import Large_MIDI_Loader, Mega_MIDI_Loader

        # Preloading (double/triple) needs the file read into real memory, so
        # force the full-read Large loader for those modes regardless of size.
        if effective >= 2 or size < MEGA_THRESHOLD:
            loader = Large_MIDI_Loader
        else:
            loader = Mega_MIDI_Loader
        info = _validate_info(loader.load(path, progress_cb=progress_cb))

    return _apply_ram_mode(info, effective, capped, max_ram_mb)


# --------------------------------------------------------------------------
# Duplication / compression
# --------------------------------------------------------------------------

def make_header(multiplier: int, division: bytes) -> bytes:
    """Build a format-1 MIDI header with ``multiplier`` tracks."""
    return (
        b"MThd"
        + b"\x00\x00\x00\x06"
        + b"\x00\x01"
        + int.to_bytes(multiplier, 2, "big")
        + division
    )


def make_single_track_header(division: bytes) -> bytes:
    """Build a format-0 MIDI header with exactly one (merged) track."""
    return (
        b"MThd"
        + b"\x00\x00\x00\x06"
        + b"\x00\x00"
        + b"\x00\x01"
        + division
    )


def human_size(num: int) -> str:
    """Format a byte count for display (e.g. ``12.4 GB``)."""
    value = float(num)
    for unit in ("B", "KB", "MB", "GB", "TB", "PB"):
        if value < 1024.0 or unit == "PB":
            if unit == "B":
                return f"{int(value)} B"
            return f"{value:.1f} {unit}"
        value /= 1024.0
    return f"{value:.1f} PB"  # pragma: no cover


def _resolve_selection(n_tracks: int, multiply_tracks) -> set:
    """Turn a selection (list of indices or ``None`` = all) into a valid set."""
    if multiply_tracks is None:
        return set(range(n_tracks))
    return {int(i) for i in multiply_tracks if 0 <= int(i) < n_tracks}


def _effective_multiplier(n_tracks: int, selected: set, multiplier: int) -> int:
    """Clamp the multiplier so the emitted track count never exceeds 65,535.

    Unselected tracks are kept once and selected tracks repeat ``multiplier``
    times, so the largest legal multiplier keeps the total at or under the
    16-bit MIDI track-count field.
    """
    if not selected:
        return 0
    unselected = n_tracks - len(selected)
    max_multiplier = max(1, (MAX_TRACKS - unselected) // len(selected))
    return max(1, min(multiplier, max_multiplier))


def plan_build(info: MidiInfo, multiplier: int,
               multiply_tracks=None) -> tuple[int, int, int, int]:
    """Compute ``(total_tracks, total_notes, uncompressed_size, eff_multiplier)``.

    ``multiply_tracks`` lists the source track indices to repeat (``None`` =
    every track). Unselected tracks are written once. The multiplier is
    clamped so the emitted track count never exceeds 65,535.
    """
    n = len(info.track_chunks)
    selected = _resolve_selection(n, multiply_tracks)
    eff = _effective_multiplier(n, selected, multiplier)
    total_tracks = 0
    total_notes = 0
    total_bytes = 0
    for i in range(n):
        reps = eff if i in selected else 1
        total_tracks += reps
        total_notes += info.track_note_counts[i] * reps
        total_bytes += len(info.track_chunks[i]) * reps
    header = make_header(min(MAX_TRACKS, total_tracks), info.division)
    return total_tracks, total_notes, len(header) + total_bytes, eff


def plan_note_build(info: MidiInfo, multiplier: int,
                    multiply_tracks=None) -> tuple[int, int, int, int]:
    """Plan a note-multiplication run (no track-count limit applies).

    Returns ``(track_count, total_notes, uncompressed_size_estimate,
    eff_multiplier)``. The output is always a single merged track, so
    ``track_count`` is 1; ``eff_multiplier`` is the unclamped multiplier
    because only the 16-bit *track* field is limited, not the note count.
    """
    n = len(info.track_chunks)
    selected = _resolve_selection(n, multiply_tracks)
    if not selected:
        return 1, 0, 0, 0
    selected_notes = sum(info.track_note_counts[i] for i in selected)
    unselected_notes = sum(
        info.track_note_counts[i] for i in range(n) if i not in selected)
    # Selected tracks' notes are multiplied; unselected tracks are merged in
    # once (the same "multiply vs. keep" rule as track duplication).
    total_notes = selected_notes * multiplier + unselected_notes
    # Notes dominate the track bytes, so scale the selected chunks by the
    # multiplier for a close-enough estimate (exact size is measured after
    # the merged track is built).
    estimate = (8 + 6) + sum(
        len(info.track_chunks[i]) * (multiplier if i in selected else 1)
        for i in range(n))
    return 1, total_notes, estimate, multiplier


def _track_event_stream(track_data: bytes, multiply: bool):
    """Yield ``(absolute_ticks, raw_event, kind, multiply)`` for one track.

    Deltas are accumulated into absolute times so several tracks can be
    merged chronologically. End-of-Track events are dropped (a fresh one is
    appended by the caller).
    """
    absolute = 0
    for delta, raw, kind in _iter_track_events(track_data):
        if kind == KIND_EOT:
            continue
        absolute += delta
        yield absolute, raw, kind, multiply


def _note_event_stream(info: MidiInfo, multiplier: int, selected: set):
    """Yield ``(delta, raw_event, kind, reps)`` for one merged, multiplied track.

    Every track is decoded lazily and merged chronologically (by absolute
    time) with a k-way merge, so memory stays flat instead of materializing
    every event in a list and sorting it (which froze the UI on big files).

    Each unique event is yielded **once**; ``reps`` is how many copies the
    caller should write (``multiplier`` for note-on/note-off events in a
    selected track, else 1). The first copy keeps its delta and the remaining
    ``reps - 1`` copies use delta 0, so the caller can expand them with a
    single C-speed ``bytes * n`` repetition instead of iterating once per
    copy — that per-copy loop is what made large multipliers crawl.
    End-of-Track events are dropped and a single new one is yielded at the
    end.
    """
    streams = [
        _track_event_stream(info.track_chunks[idx][8:], idx in selected)
        for idx in range(len(info.track_chunks))
    ]

    previous = 0
    for absolute, raw, kind, multiply in heapq.merge(
            *streams, key=lambda entry: entry[0]):
        delta = absolute - previous
        previous = absolute
        if multiply and kind in (KIND_NOTE_ON, KIND_NOTE_OFF):
            reps = multiplier
        else:
            reps = 1
        yield delta, raw, kind, reps
    yield 0, b"\xff\x2f\x00", KIND_EOT, 1  # single End-of-Track at the very end


def build_duplicated_xz(
    input_path: str,
    output_path: str,
    multiplier: int,
    preset: int = 6,
    fast: bool = False,
    double_compress: bool = False,
    progress_cb=None,
    progress2_cb=None,
    cancel_event=None,
    info: MidiInfo | None = None,
    multiply_tracks=None,
) -> BuildResult:
    """Duplicate the selected MIDI tracks ``multiplier`` times into ``output_path``.

    ``multiply_tracks`` lists the source track indices to repeat (``None`` =
    every track); unselected tracks are written once. ``progress_cb(done,
    total, notes_done, bytes_done)`` reports progress in written track chunks
    plus cumulative notes/bytes; ``progress2_cb(done, total)`` reports the
    optional second (.xz.xz) pass in bytes. ``cancel_event`` is an optional
    :class:`threading.Event`.

    ``info`` is an optional already-parsed :class:`MidiInfo` (e.g. the one the
    UI keeps in memory after the file is chosen). When provided the file is
    **not** re-read from disk, so repeated runs skip the slow parse step.
    """
    if not MIN_TRACKS <= multiplier <= MAX_TRACKS:
        raise MidiError(
            f"Multiplier must be between {MIN_TRACKS} and {MAX_TRACKS}, got {multiplier}."
        )
    if not 0 <= preset <= 9:
        raise MidiError(f"Compression preset must be 0-9, got {preset}.")

    if info is None:
        info = validate_multi_track(input_path)

    n = len(info.track_chunks)
    selected = _resolve_selection(n, multiply_tracks)
    if not selected:
        raise MidiError("Select at least one track to multiply.")

    # Plan first so the capped multiplier and totals are shared with the UI.
    total_tracks, total_notes, uncompressed, eff = plan_build(
        info, multiplier, multiply_tracks)

    # (chunk bytes, note count, repetitions) in output order.
    order = [
        (info.track_chunks[i], info.track_note_counts[i],
         eff if i in selected else 1)
        for i in range(n)
    ]

    header = make_header(min(MAX_TRACKS, total_tracks), info.division)

    filters = [{"id": lzma.FILTER_LZMA2, "preset": preset}]
    started = time.perf_counter()
    step = max(1, total_tracks // 1000)  # ~1000 progress callbacks at most

    out_dir = os.path.dirname(os.path.abspath(output_path))
    os.makedirs(out_dir, exist_ok=True)

    state = {"done": 0, "notes": 0, "bytes": len(header)}

    def _report() -> None:
        if progress_cb is not None and (
                state["done"] % step == 0 or state["done"] == total_tracks):
            progress_cb(state["done"], total_tracks, state["notes"],
                        state["bytes"])

    def _after_chunk(chunk: bytes, nc: int) -> None:
        state["done"] += 1
        state["notes"] += nc
        state["bytes"] += len(chunk)
        _report()

    def _check_cancel() -> None:
        if cancel_event is not None and cancel_event.is_set():
            raise Cancelled()

    def _first_pass(out) -> None:
        if fast:
            # Compress each unique part once, then repeat the compressed
            # blocks. Produces valid concatenated XZ streams.
            out.write(lzma.compress(header, preset=preset))
            xz_cache = {}
            for chunk, nc, reps in order:
                block = xz_cache.setdefault(
                    chunk, lzma.compress(chunk, preset=preset))
                for _ in range(reps):
                    _check_cancel()
                    out.write(block)
                    _after_chunk(chunk, nc)
        else:
            # One continuous XZ stream: LZMA exploits the repetition and the
            # result is dramatically smaller than the fast path.
            compressor = lzma.LZMACompressor(
                format=lzma.FORMAT_XZ,
                check=lzma.CHECK_CRC64,
                filters=filters,
            )
            out.write(compressor.compress(header))
            for chunk, nc, reps in order:
                for _ in range(reps):
                    _check_cancel()
                    out.write(compressor.compress(chunk))
                    _after_chunk(chunk, nc)
            out.write(compressor.flush())

    if double_compress:
        # First pass buffers the .xz in memory so we can recompress it.
        stage = io.BytesIO()
        _first_pass(stage)
        stage_bytes = stage.getvalue()
        stage.close()

        # Second pass: compress the .xz stream again into .xz.xz.
        with open(output_path, "wb") as out:
            second = lzma.LZMACompressor(
                format=lzma.FORMAT_XZ,
                check=lzma.CHECK_CRC64,
                filters=filters,
            )
            total = len(stage_bytes)
            chunk = 1 << 20  # 1 MiB at a time keeps memory flat
            done = 0
            for i in range(0, total, chunk):
                _check_cancel()
                piece = stage_bytes[i:i + chunk]
                out.write(second.compress(piece))
                done += len(piece)
                if progress2_cb is not None:
                    progress2_cb(done, total)
            out.write(second.flush())
            if progress2_cb is not None:
                progress2_cb(total, total)
    else:
        with open(output_path, "wb") as out:
            _first_pass(out)

    elapsed = time.perf_counter() - started
    return BuildResult(
        output_path=output_path,
        multiplier=multiplier,
        track_count=total_tracks,
        total_notes=total_notes,
        input_size=info.input_size,
        uncompressed_size=uncompressed,
        compressed_size=os.path.getsize(output_path),
        elapsed=elapsed,
        fast_mode=fast,
        double_compress=double_compress,
        selected_tracks=tuple(sorted(selected)),
        per_track_notes=tuple(info.track_note_counts),
        effective_multiplier=eff,
    )


def build_note_multiplied_xz(
    input_path: str,
    output_path: str,
    multiplier: int,
    preset: int = 6,
    fast: bool = False,
    double_compress: bool = False,
    progress_cb=None,
    progress2_cb=None,
    cancel_event=None,
    info: MidiInfo | None = None,
    multiply_tracks=None,
    speed: str = "balanced",
) -> BuildResult:
    """Duplicate every note in the selected tracks and merge them into one track.

    Unlike :func:`build_duplicated_xz` (which repeats whole tracks, hitting
    the 65,535-track limit), this multiplies each note-on/note-off ``multiplier``
    times and writes the result as a single format-0 track, so the note count
    is limited only by memory and disk, not the MIDI track field.

    Progress is reported in notes: ``progress_cb(done, total, notes_done,
    bytes_done)`` where ``done`` and ``total`` are note-on counts.
    ``progress2_cb(done, total)`` reports the optional .xz.xz second pass in
    bytes. ``fast`` is accepted for API symmetry but is ignored — the merged
    track is not a simple repetition, so it is always streamed.

    ``speed`` is one of ``"balanced"``, ``"fast"`` or ``"turbo"`` (see
    :data:`MERGE_SPEEDS`). Faster tiers lower the LZMA preset and buffer more
    merged-track bytes before each compress() call, trading output size for
    throughput.
    """
    if not MIN_TRACKS <= multiplier <= MAX_TRACKS:
        raise MidiError(
            f"Multiplier must be between {MIN_TRACKS} and {MAX_TRACKS}, got {multiplier}.")
    if not 0 <= preset <= 9:
        raise MidiError(f"Compression preset must be 0-9, got {preset}.")

    if info is None:
        info = validate_multi_track(input_path)

    n = len(info.track_chunks)
    selected = _resolve_selection(n, multiply_tracks)
    if not selected:
        raise MidiError("Select at least one track to multiply.")

    track_count, total_notes, estimate, eff = plan_note_build(
        info, multiplier, multiply_tracks)

    # Fail fast when the merged track is already obviously over the MIDI
    # format's 4 GB per-track limit, instead of building for minutes/hours and
    # then dying on ``int.to_bytes(track_len, 4, ...)`` with an opaque
    # "int too big to convert" OverflowError.
    if estimate > MAX_TRACK_BYTES:
        raise MidiError(
            "The merged track would be about "
            f"{human_size(estimate)}, but a MIDI track is limited to "
            f"{human_size(MAX_TRACK_BYTES)} (4 GB). Lower the multiplier or "
            "use track duplication instead.")

    header = make_single_track_header(info.division)
    speed_cfg = MERGE_SPEEDS.get(speed, MERGE_SPEEDS["balanced"])
    # Lower presets compress far faster (at the cost of a bigger file); the
    # speed tier clamps the user's preset downward instead of overriding it
    # so the normal 0-9 preset still works in "balanced" mode.
    effective_preset = min(preset, speed_cfg["preset_max"])
    buffer_size = speed_cfg["buffer"]
    filters = [{"id": lzma.FILTER_LZMA2, "preset": effective_preset}]
    started = time.perf_counter()
    step = max(1, total_notes // 1000)  # ~1000 progress callbacks at most

    out_dir = os.path.dirname(os.path.abspath(output_path))
    os.makedirs(out_dir, exist_ok=True)

    state = {"notes": 0, "bytes": len(header) + 8}

    def _check_cancel() -> None:
        if cancel_event is not None and cancel_event.is_set():
            raise Cancelled()

    def _report() -> None:
        if progress_cb is not None and (
                state["notes"] % step == 0 or state["notes"] == total_notes):
            progress_cb(state["notes"], total_notes, state["notes"],
                        state["bytes"])

    # The merged track is decoded, multiplied and compressed in ONE streaming
    # pass into a temp file, while its exact uncompressed length is counted.
    # This replaces the old approach — materializing every event in a list,
    # sorting it, then decoding it all over again — which ballooned memory and
    # froze the UI on large files. The temp file holds only the *compressed*
    # track, so it stays small even when the uncompressed MIDI is enormous.
    fd, track_xz_path = tempfile.mkstemp(
        prefix=".trillion_track_", suffix=".xz", dir=out_dir)
    track_xz = os.fdopen(fd, "wb")
    track_len = 0
    try:
        track_compressor = lzma.LZMACompressor(
            format=lzma.FORMAT_XZ,
            check=lzma.CHECK_CRC64,
            filters=filters,
        )
        # Buffer the merged events and compress in bulk. Two things used to
        # make this path crawl at a few MB/s: calling compress() once per
        # ~5-byte event, and looping once per *duplicate* of every note. The
        # first copy keeps its delta and the remaining copies use delta 0, so
        # they are expanded with one C-speed ``bytes * n`` repetition instead
        # of a Python loop per copy. Batching removes the per-event compress()
        # overhead; the repetition removes the per-copy loop.
        buf = bytearray()
        for delta, raw, kind, reps in _note_event_stream(
                info, multiplier, selected):
            _check_cancel()
            enc_delta = b"\x00" if delta == 0 else _encode_vlq(delta)
            if reps > 1:
                piece = enc_delta + raw + (b"\x00" + raw) * (reps - 1)
            else:
                piece = enc_delta + raw
            buf += piece
            piece_len = len(piece)
            track_len += piece_len
            state["bytes"] += piece_len
            if track_len > MAX_TRACK_BYTES:
                raise MidiError(
                    "The merged track exceeds the MIDI format's 4 GB "
                    "per-track limit. Lower the multiplier or use track "
                    "duplication instead.")
            if kind == KIND_NOTE_ON:
                state["notes"] += reps
                _report()
            if len(buf) >= buffer_size:
                track_xz.write(track_compressor.compress(bytes(buf)))
                buf.clear()
        if buf:
            track_xz.write(track_compressor.compress(bytes(buf)))
        track_xz.write(track_compressor.flush())
        track_xz.close()
        track_xz = None
        uncompressed = len(header) + 8 + track_len

        # The header (with the now-known track length) is a tiny standalone XZ
        # stream concatenated in front of the compressed track. Concatenated XZ
        # streams are valid and already used by the "fast" duplication path.
        head_block = lzma.compress(
            header + CHUNK_TRACK + int.to_bytes(track_len, 4, "big"),
            format=lzma.FORMAT_XZ,
            check=lzma.CHECK_CRC64,
            preset=effective_preset,
        )

        def _assemble(out) -> None:
            out.write(head_block)
            chunk = 1 << 20
            with open(track_xz_path, "rb") as src:
                while True:
                    _check_cancel()
                    piece = src.read(chunk)
                    if not piece:
                        break
                    out.write(piece)

        if double_compress:
            # Buffer the concatenated .xz in memory so we can recompress it.
            stage = io.BytesIO()
            _assemble(stage)
            stage_bytes = stage.getvalue()
            stage.close()

            with open(output_path, "wb") as out:
                second = lzma.LZMACompressor(
                    format=lzma.FORMAT_XZ,
                    check=lzma.CHECK_CRC64,
                    filters=filters,
                )
                total = len(stage_bytes)
                chunk = 1 << 20  # 1 MiB at a time keeps memory flat
                done = 0
                for i in range(0, total, chunk):
                    _check_cancel()
                    piece = stage_bytes[i:i + chunk]
                    out.write(second.compress(piece))
                    done += len(piece)
                    if progress2_cb is not None:
                        progress2_cb(done, total)
                out.write(second.flush())
                if progress2_cb is not None:
                    progress2_cb(total, total)
        else:
            with open(output_path, "wb") as out:
                _assemble(out)
    finally:
        if track_xz is not None:
            try:
                track_xz.close()
            except Exception:
                pass
        try:
            os.remove(track_xz_path)
        except OSError:
            pass

    elapsed = time.perf_counter() - started
    return BuildResult(
        output_path=output_path,
        multiplier=multiplier,
        track_count=track_count,
        total_notes=total_notes,
        input_size=info.input_size,
        uncompressed_size=uncompressed,
        compressed_size=os.path.getsize(output_path),
        elapsed=elapsed,
        fast_mode=fast,
        double_compress=double_compress,
        selected_tracks=tuple(sorted(selected)),
        per_track_notes=tuple(info.track_note_counts),
        effective_multiplier=eff,
        note_mode=True,
    )
