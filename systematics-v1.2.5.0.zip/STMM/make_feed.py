"""Generate feed.json for Systematics TRILLION MIDI maker.

Run this script whenever you release a new version. It writes a feed.json
that the app reads (UPDATE_FEED_URL in CORE_FILES/updater.py), including the
list of older releases used by Settings > Downgrade.

Usage::

    python make_feed.py 1.2.0.0 "https://example.com/systematics-1.2.0.0.zip" \
        "Release notes for 1.2.0.0"

It keeps the previous "version" as an entry in the "versions" list
automatically, so the history grows as you release. Re-run it for the SAME
version to just refresh notes/URL without adding a duplicate history entry.

Then upload feed.json to your GitHub Pages repo root so it's served at
https://<user>.github.io/feed.json (and update DEFAULT_FEED_URL if yours
differs).
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

DEFAULT_OUT = Path(__file__).resolve().parent / "feed.json"


def parse_version(version: str) -> tuple:
    """Turn '1.2.3.4' into a comparable tuple (same rule as updater.py)."""
    parts: list[int] = []
    for piece in str(version).strip().split("."):
        digits = "".join(ch for ch in piece if ch.isdigit())
        parts.append(int(digits) if digits else 0)
    while len(parts) < 4:
        parts.append(0)
    return tuple(parts[:4])


def load_existing(path: Path) -> dict:
    try:
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
        if isinstance(data, dict):
            return data
    except (OSError, ValueError):
        pass
    return {}


def build_feed(new_version: str, url: str, notes: str, name: str,
               existing: dict, max_history: int = 30) -> dict:
    """Return the new feed dict, folding the old current release into history."""
    history: list[dict] = []
    seen: set = set()

    # The old top-level release becomes the first history entry.
    old_version = str(existing.get("version", "")).strip()
    if old_version and old_version != new_version:
        history.append({
            "version": old_version,
            "notes": str(existing.get("notes", "")),
            "url": str(existing.get("url", "")),
        })
        seen.add(old_version)

    # Then the previously stored history, minus duplicates.
    for item in existing.get("versions", []):
        if not isinstance(item, dict):
            continue
        v = str(item.get("version", "")).strip()
        if not v or v in seen or v == new_version:
            continue
        history.append({
            "version": v,
            "notes": str(item.get("notes", "")),
            "url": str(item.get("url", "")),
        })
        seen.add(v)

    history.sort(key=lambda e: parse_version(e["version"]), reverse=True)
    return {
        "version": new_version,
        "name": name,
        "notes": notes,
        "url": url,
        "versions": history[:max_history],
    }


def main() -> None:
    ap = argparse.ArgumentParser(
        description="Generate feed.json for Systematics TRILLION MIDI maker.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=__doc__.split("Usage::")[1].split("Then upload")[0].strip())
    ap.add_argument("version", help="new version, e.g. 1.2.0.0")
    ap.add_argument("url", help="direct download URL of the release zip")
    ap.add_argument("notes", nargs="?", default="",
                    help="release notes (single line, or use --notes-file)")
    ap.add_argument("--name", default="Systematics TRILLION MIDI maker",
                    help="app name shown in the update dialog")
    ap.add_argument("--notes-file", help="read release notes from this file")
    ap.add_argument("--out", default=str(DEFAULT_OUT),
                    help=f"output path (default: {DEFAULT_OUT})")
    ap.add_argument("--max-history", type=int, default=30,
                    help="max number of older releases to keep (default 30)")
    args = ap.parse_args()

    notes = args.notes
    if args.notes_file:
        try:
            notes = Path(args.notes_file).read_text(encoding="utf-8").strip()
        except OSError as exc:
            print(f"error: could not read notes file: {exc}", file=sys.stderr)
            return 1
    if not notes:
        print("warning: no release notes given (feed.json will have empty notes)",
              file=sys.stderr)

    out = Path(args.out)
    feed = build_feed(args.version, args.url, notes, args.name,
                      load_existing(out), args.max_history)

    tmp = out.with_suffix(".json.tmp")
    tmp.write_text(json.dumps(feed, indent=2) + "\n", encoding="utf-8")
    tmp.replace(out)
    print(f"Wrote {out}")
    print(f"  current : {feed['version']}")
    print(f"  history : {len(feed['versions'])} older release(s)")
    for v in feed["versions"]:
        print(f"    - {v['version']}")


if __name__ == "__main__":
    raise SystemExit(main())
