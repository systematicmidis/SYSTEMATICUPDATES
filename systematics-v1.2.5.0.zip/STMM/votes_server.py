"""Tiny vote-collection server for Systematics TRILLION MIDI maker polls.

Run it on any always-on computer (or a cheap VPS) and point each poll's
``submit_url`` / ``results_url`` at it::

    python votes_server.py                 # serves on http://0.0.0.0:8000
    python votes_server.py --port 9000 --data /path/to/votes.json

Endpoints
---------
GET  /                          simple status page
POST /vote                      body: {"poll": "favorite-mode", "votes": [0, 2]}
GET  /results?poll=favorite-mode   -> {"votes": [12, 5, 2], "total": 19}

Votes are appended to a JSON file (``votes.json`` by default) so they survive
restarts. Only the Python standard library is used — no pip installs needed.
"""

from __future__ import annotations

import argparse
import json
import os
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, urlparse


def load_store(path: str) -> dict:
    try:
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
            if isinstance(data, dict):
                return data
    except (OSError, ValueError):
        pass
    return {}


def save_store(path: str, store: dict) -> None:
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(store, f, indent=2)
    os.replace(tmp, path)


def tally(store: dict, poll_id: str):
    """Sum every stored vote for a poll into per-option counts."""
    votes = store.get(poll_id)
    if not isinstance(votes, list) or not votes:
        return [], 0
    # Size by the highest option index actually voted for, not by how many
    # options a single vote contains (a [1] vote must land in slot 1).
    width = 0
    for v in votes:
        if isinstance(v, list):
            for i in v:
                if isinstance(i, int) and i >= 0 and i + 1 > width:
                    width = i + 1
    counts = [0] * width
    for v in votes:
        if isinstance(v, list):
            for i in v:
                if isinstance(i, int) and 0 <= i < width:
                    counts[i] += 1
    return counts, len(votes)


def make_handler(store: dict, lock: threading.Lock, data_path: str):
    class Handler(BaseHTTPRequestHandler):
        def log_message(self, _fmt, *_args):
            pass  # keep the console quiet

        def _send(self, code: int, payload, content_type: str = "application/json") -> None:
            body = (payload if isinstance(payload, bytes)
                    else json.dumps(payload).encode("utf-8"))
            self.send_response(code)
            self.send_header("Content-Type", content_type)
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)

        def do_GET(self) -> None:
            parsed = urlparse(self.path)
            if parsed.path in ("/", "/status"):
                return self._send(200, {"ok": True,
                                        "service": "Systematics poll server",
                                        "polls": sorted(store.keys())})
            if parsed.path == "/results":
                poll_id = (parse_qs(parsed.query).get("poll") or [""])[0]
                with lock:
                    counts, total = tally(store, poll_id)
                return self._send(200, {"votes": counts, "total": total})
            self._send(404, {"error": "not found"})

        def do_POST(self) -> None:
            parsed = urlparse(self.path)
            if parsed.path != "/vote":
                return self._send(404, {"error": "not found"})
            try:
                length = int(self.headers.get("Content-Length") or 0)
                raw = self.rfile.read(length) if length else b"{}"
                body = json.loads(raw.decode("utf-8", errors="replace"))
            except Exception:
                return self._send(400, {"error": "bad JSON body"})
            poll_id = str(body.get("poll", "")).strip()
            votes = body.get("votes")
            if not poll_id:
                return self._send(400, {"error": "missing 'poll'"})
            if (not isinstance(votes, list) or not votes
                    or not all(isinstance(i, int) and 0 <= i < 1000 for i in votes)):
                return self._send(400, {"error": "votes must be a non-empty list "
                                                 "of integers"})
            with lock:
                store.setdefault(poll_id, []).append([int(i) for i in votes])
                save_store(data_path, store)
            return self._send(200, {"ok": True, "poll": poll_id})

    return Handler


def main() -> None:
    ap = argparse.ArgumentParser(description="Systematics poll vote server")
    ap.add_argument("--host", default="0.0.0.0")
    # Hosting platforms (Railway, Render, Heroku, ...) inject a PORT env var.
    ap.add_argument("--port", type=int,
                    default=int(os.environ.get("PORT", "8000")))
    ap.add_argument("--data",
                    default=os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                         "votes.json"))
    args = ap.parse_args()

    store = load_store(args.data)
    lock = threading.Lock()
    server = ThreadingHTTPServer((args.host, args.port),
                                 make_handler(store, lock, args.data))
    print(f"Systematics poll server running on http://{args.host}:{args.port}")
    print(f"Votes stored in: {args.data}")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nStopped.")


if __name__ == "__main__":
    main()
