/**
 * votes_worker.js — fully automatic vote backend for Systematics TRILLION
 * MIDI maker polls, as a Cloudflare Worker + Durable Object.
 *
 * No repo, no server to maintain: paste this file into the Cloudflare
 * dashboard, add one Durable Object binding, and it's live forever on the
 * free tier (never sleeps).
 *
 * Setup (dash.cloudflare.com):
 *   1. Workers & Pages → Create → Create Worker → give it a name → Deploy.
 *   2. Open the worker → Edit code (Quick Edit) → replace the default code
 *      with the contents of THIS file → Deploy.
 *   3. Settings → Durable Objects → Add binding:
 *          Binding name:  POLLS      (must match the code exactly)
 *          Class name:    PollTally
 *      Then re-deploy.
 *   4. Your URL is:  https://<worker-name>.<your-subdomain>.workers.dev
 *
 * Then in news.json, give each poll:
 *     "submit_url":   "https://<worker-name>.<your-subdomain>.workers.dev/vote"
 *     "results_url":  "https://<worker-name>.<your-subdomain>.workers.dev/results"
 *
 * API:
 *     POST /vote                  body: {"poll": "<id>", "votes": [0, 2]}
 *     GET  /results?poll=<id>     -> {"votes": [12, 5, 2], "total": 19}
 *     GET  /status                health check
 *
 * Votes live in the Durable Object's persistent (SQLite-backed) storage,
 * which is strongly consistent — a vote you just cast shows up immediately.
 * Each vote is appended, one-entry per POST, like votes_server.py.
 */

export default {
  async fetch(request, env) {
    const url = new URL(request.url);

    if (!env.POLLS) {
      return json({
        error: "Missing POLLS Durable Object binding. Add one in Settings → "
               + "Durable Objects (binding name: POLLS, class: PollTally).",
      }, 500);
    }

    try {
      if (request.method === "GET" && (url.pathname === "/" || url.pathname === "/status")) {
        return json({ ok: true, service: "Systematics poll worker (Cloudflare)" });
      }

      if (request.method === "POST" && url.pathname === "/vote") {
        // Read a clone so the original body stays intact for the Durable Object.
        const body = await request.clone().json().catch(() => null);
        const poll = String((body && body.poll) || "").trim();
        if (!poll) {
          return json({ error: "missing 'poll'" }, 400);
        }
        const stub = env.POLLS.get(env.POLLS.idFromName(poll));
        return stub.fetch(request);
      }

      if (request.method === "GET" && url.pathname === "/results") {
        const poll = url.searchParams.get("poll") || "";
        if (!poll) {
          return json({ error: "missing 'poll'" }, 400);
        }
        const stub = env.POLLS.get(env.POLLS.idFromName(poll));
        return stub.fetch(request);
      }

      return json({ error: "not found" }, 404);
    } catch (err) {
      return json({ error: "worker error: " + ((err && err.message) || err) }, 500);
    }
  },
};

/**
 * One Durable Object instance per poll id. Cloudflare runs each instance on a
 * single thread, so the read-modify-write tally below can never lose a vote,
 * and its storage is persistent and strongly consistent.
 */
export class PollTally {
  constructor(state) {
    this.storage = state.storage;
  }

  async fetch(request) {
    if (request.method === "POST") {
      const body = await request.json().catch(() => null);
      const poll = String((body && body.poll) || "").trim();
      const votes = body && Array.isArray(body.votes) ? body.votes : null;
      if (!poll) {
        return json({ error: "missing 'poll'" }, 400);
      }
      if (!votes || votes.length === 0
          || !votes.every((v) => Number.isInteger(v) && v >= 0 && v < 1000)) {
        return json({ error: "votes must be a non-empty list of integers" }, 400);
      }
      const key = "votes";
      const all = (await this.storage.get(key)) || [];
      all.push(votes.map(Number));
      await this.storage.put(key, all);
      return json({ ok: true, poll });
    }

    if (request.method === "GET") {
      const all = (await this.storage.get("votes")) || [];
      // Size the counts array by the HIGHEST option index actually voted
      // for (not by how many options a single vote contains). A vote of
      // [1] must land in slot 1 even if no one ever picked option 0.
      let width = 0;
      for (const v of all) {
        if (!Array.isArray(v)) {
          continue;
        }
        for (const i of v) {
          if (Number.isInteger(i) && i >= 0 && i + 1 > width) {
            width = i + 1;
          }
        }
      }
      const counts = new Array(width).fill(0);
      for (const v of all) {
        if (!Array.isArray(v)) {
          continue;
        }
        for (const i of v) {
          if (Number.isInteger(i) && i >= 0 && i < width) {
            counts[i]++;
          }
        }
      }
      return json({ votes: counts, total: all.length });
    }

    return json({ error: "method not allowed" }, 405);
  }
}

function json(data, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: {
      "Content-Type": "application/json",
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
      "Access-Control-Allow-Headers": "Content-Type",
    },
  });
}