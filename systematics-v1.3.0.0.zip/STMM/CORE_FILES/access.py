"""One-time password gate for Systematics TRILLION MIDI maker.

The app asks for a password **once per device**. On success the activation
server (a Cloudflare Worker, see ``access-worker.js``) records the caller's IP
as a trusted address and returns a token; the token is cached locally so the
user never has to type the password again on this machine.

Design notes / honest limitations
---------------------------------
* The password itself lives on the server, never in the app. This module only
  knows the *server URL*, the *endpoints*, and how to talk to them.
* The server URL is obfuscated below (XOR + base64) **only** to keep it from
  being readable by casual poking around. This is NOT real security: anyone
  who can run the app can extract the URL from this file, watch their own
  network traffic, or run a proxy. The real protection is the server's admin
  key and the password itself — a hidden URL is just a speed bump.
* "Trusted" is keyed to the local token first (so users stay unlocked when
  their IP changes or the server is briefly unreachable). The server also
  records the IP, so you can see who has unlocked it.
* The password rotates on the server every 1-3 days (default 2). Users who
  already unlocked stay unlocked; only *new* devices need the current
  password, which you read from the server's admin page.
"""

from __future__ import annotations

import base64
import itertools
import json
import os
import time
import urllib.error
import urllib.request

import tkinter as tk

from . import APP_NAME
from . import settings as app_settings

# Local trust record: ``{token, ip, granted_at}``. Deleting this file makes
# the app ask for the password again.
TRUST_FILE = os.path.join(os.path.expanduser("~"), ".systematics_access.json")

TIMEOUT = 8  # seconds for server calls

# --------------------------------------------------------------------------
# Server address (obfuscated — see the module docstring for why).
# --------------------------------------------------------------------------
_XOR_KEY = b"ST-Access-Key-9#"
_OBFUSCATED_URL = "OyBZMRBZSlwSTigACl4XUConWSQOAhEaEAAmDB1ESg0kO18qBhEWXRdIPQ=="


def _xor_b64(payload: str) -> str:
    """Decode the XOR+base64 obfuscation used for the server URL.

    This is the "decode the link" helper. Run this file directly to print the
    real URL:
        python -m CORE_FILES.access
    """
    raw = base64.b64decode(payload.encode("ascii"))
    return bytes(a ^ b for a, b in zip(raw, itertools.cycle(_XOR_KEY))).decode()


def _server_url() -> str:
    return _xor_b64(_OBFUSCATED_URL)


class AccessError(Exception):
    """Raised when the activation server can't verify the user."""


# --------------------------------------------------------------------------
# Local trust record
# --------------------------------------------------------------------------

def _load_trust() -> dict:
    try:
        with open(TRUST_FILE, "r", encoding="utf-8") as f:
            data = json.load(f)
            return data if isinstance(data, dict) else {}
    except (OSError, ValueError):
        return {}


def _save_trust(data: dict) -> None:
    try:
        with open(TRUST_FILE, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2)
    except OSError:
        pass


def is_trusted() -> bool:
    """True when this device has already unlocked the app once."""
    return bool(_load_trust().get("token"))


# Cloudflare blocks requests without a browser signature (HTTP 403 error
# 1010). Send a normal browser User-Agent so the activation call is not
# mistaken for a bot.
_USER_AGENT = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
    "AppleWebKit/537.36 (KHTML, like Gecko) "
    "Chrome/127.0 Safari/537.36"
)


def _post(path: str, payload: dict) -> dict:
    """POST JSON to the activation server and return the decoded response."""
    request = urllib.request.Request(
        _server_url() + path,
        data=json.dumps(payload).encode("utf-8"),
        headers={
            "Content-Type": "application/json",
            "Accept": "application/json",
            "User-Agent": _USER_AGENT,
        },
        method="POST",
    )
    try:
        with urllib.request.urlopen(request, timeout=TIMEOUT) as resp:
            raw = resp.read().decode("utf-8", "replace")
            data = json.loads(raw)
    except urllib.error.HTTPError as exc:
        # The server returned an error status (e.g. admin 401). Try to read
        # the JSON body so the real message reaches the user.
        try:
            body = json.loads(exc.read().decode("utf-8", "replace"))
            if isinstance(body, dict) and body.get("error"):
                raise AccessError(str(body["error"])) from exc
        except AccessError:
            raise
        except (ValueError, OSError):
            pass
        raise AccessError(
            "The activation server rejected the request "
            f"(HTTP {exc.code})."
        ) from exc
    except urllib.error.URLError as exc:
        raise AccessError(
            "Could not reach the activation server.\n"
            "Check your internet connection and try again."
        ) from exc
    except (ValueError, OSError) as exc:
        raise AccessError(
            "The activation server returned an invalid response."
        ) from exc
    return data if isinstance(data, dict) else {}


def verify_password(password: str) -> dict:
    """Ask the server to accept ``password``. Returns ``{ok, token, ip}``."""
    data = _post("/verify", {"password": password})
    if data.get("ok") and data.get("token"):
        return data
    raise AccessError(str(data.get("error") or "Incorrect password."))


# --------------------------------------------------------------------------
# Themed dialog
# --------------------------------------------------------------------------

_PALETTES = {
    "dark": {
        "BG": "#1b1b1b", "CARD": "#232323", "BORDER": "#343434",
        "ACCENT": "#00AEEF", "ACCENT_ON": "#06222e", "TEXT": "#f2f2f2",
        "MUTED": "#8f8f8f", "FIELD": "#242424", "ERROR": "#e5484d",
    },
    "light": {
        "BG": "#f2f2f2", "CARD": "#ffffff", "BORDER": "#d0d0d0",
        "ACCENT": "#0080c0", "ACCENT_ON": "#ffffff", "TEXT": "#1b1b1b",
        "MUTED": "#5f5f5f", "FIELD": "#ffffff", "ERROR": "#c62828",
    },
}


def _font(size: int, weight: str = "normal") -> tuple:
    return ("Segoe UI", size, weight)


def _enable_dark_titlebar(root: tk.Tk, dark: bool = True) -> None:
    """Ask Windows to render the dialog's title bar dark (or light)."""
    if os.name != "nt":
        return
    try:
        import ctypes

        user32 = ctypes.WinDLL("user32")
        dwmapi = ctypes.WinDLL("dwmapi")
        user32.GetParent.restype = ctypes.c_void_p
        user32.GetParent.argtypes = [ctypes.c_void_p]
        dwmapi.DwmSetWindowAttribute.restype = ctypes.c_long
        dwmapi.DwmSetWindowAttribute.argtypes = [
            ctypes.c_void_p, ctypes.c_uint, ctypes.c_void_p, ctypes.c_uint]
        root.update_idletasks()
        hwnd = user32.GetParent(ctypes.c_void_p(root.winfo_id()))
        enabled = ctypes.c_int(1 if dark else 0)
        for attribute in (20, 19):
            if dwmapi.DwmSetWindowAttribute(
                    hwnd, attribute, ctypes.byref(enabled),
                    ctypes.sizeof(enabled)) == 0:
                break
    except Exception:
        pass


def _prompt_password() -> dict | None:
    """Show the unlock dialog. Returns ``{token, ip, ...}`` or ``None``.

    The password is verified while the dialog stays open, so a wrong password
    or an unreachable server shows an inline error and lets the user retry.
    """
    theme = "dark"
    try:
        saved = app_settings.load().get("theme", "dark")
        if saved in _PALETTES:
            theme = saved
    except Exception:
        pass
    p = _PALETTES[theme]

    result: dict | None = None
    root = tk.Tk()
    root.title(APP_NAME)
    root.configure(bg=p["BG"])
    root.resizable(False, False)
    _enable_dark_titlebar(root, dark=(theme == "dark"))

    card = tk.Frame(root, bg=p["CARD"], highlightthickness=1,
                    highlightbackground=p["BORDER"])
    card.pack(fill="both", expand=True, padx=24, pady=24)

    tk.Label(card, text="Locked", bg=p["CARD"], fg=p["ACCENT"],
             font=_font(13, "bold")).pack(anchor="w", pady=(20, 4))
    tk.Label(card, text="Enter the access password to unlock this app.",
             bg=p["CARD"], fg=p["TEXT"], font=_font(10),
             justify="left", wraplength=360).pack(anchor="w")
    tk.Label(card, text="This is asked once per device.",
             bg=p["CARD"], fg=p["MUTED"], font=_font(9),
             justify="left", wraplength=360).pack(anchor="w", pady=(2, 14))

    entry = tk.Entry(card, show="\u2022", bg=p["FIELD"], fg=p["TEXT"],
                     insertbackground=p["TEXT"], relief="flat",
                     font=_font(11), width=30)
    entry.pack(fill="x", padx=2, pady=(0, 6), ipady=6)

    status = tk.Label(card, text="", bg=p["CARD"], fg=p["ERROR"],
                      font=_font(9), anchor="w", wraplength=360)
    status.pack(fill="x", pady=(0, 6))

    def _unlock() -> None:
        nonlocal result
        password = entry.get().strip()
        if not password:
            status.configure(text="Enter the access password.")
            entry.focus_set()
            return
        status.configure(text="Checking\u2026", fg=p["MUTED"])
        root.update()
        try:
            data = verify_password(password)
        except AccessError as exc:
            status.configure(text=str(exc), fg=p["ERROR"])
            entry.delete(0, "end")
            entry.focus_set()
            return
        result = data
        root.destroy()

    def _cancel() -> None:
        nonlocal result
        result = None
        root.destroy()

    row = tk.Frame(card, bg=p["CARD"])
    row.pack(fill="x", pady=(10, 20))
    tk.Button(row, text="Unlock", command=_unlock, bg=p["ACCENT"],
              fg=p["ACCENT_ON"], activebackground=p["ACCENT"],
              activeforeground=p["ACCENT_ON"], relief="flat", padx=18, pady=7,
              font=_font(10, "bold"), cursor="hand2").pack(side="left")
    tk.Button(row, text="Cancel", command=_cancel, bg=p["BORDER"],
              fg=p["TEXT"], activebackground=p["BORDER"],
              activeforeground=p["TEXT"], relief="flat", padx=18, pady=7,
              font=_font(10), cursor="hand2").pack(side="left", padx=(8, 0))

    entry.focus_set()
    entry.bind("<Return>", lambda _e: _unlock())
    root.bind("<Escape>", lambda _e: _cancel())

    # Center on screen.
    root.update_idletasks()
    w = root.winfo_reqwidth()
    h = root.winfo_reqheight()
    x = max(0, (root.winfo_screenwidth() - w) // 2)
    y = max(0, (root.winfo_screenheight() - h) // 3)
    root.geometry(f"+{x}+{y}")

    root.mainloop()
    return result


# --------------------------------------------------------------------------
# Entry point
# --------------------------------------------------------------------------

def gate() -> bool:
    """Unlock the app. Called once from ``app.main()`` before the UI starts.

    Returns ``True`` when the app may start (already trusted, or the password
    was accepted), ``False`` when the user cancelled (the app should exit).
    """
    if is_trusted():
        return True

    data = _prompt_password()
    if not data:
        return False

    _save_trust({
        "token": data.get("token", ""),
        "ip": data.get("ip", ""),
        "granted_at": int(time.time()),
    })
    return True


if __name__ == "__main__":
    print("Server URL:", _server_url())
