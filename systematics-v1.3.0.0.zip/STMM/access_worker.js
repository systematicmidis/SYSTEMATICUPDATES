/**
 * access_worker.js — one-time password gate backend for Systematics TRILLION
 * MIDI maker (Cloudflare Worker + Durable Object).
 *
 * This uses the SAME legacy Durable Object style as votes_worker.js (your
 * polls worker) because that pattern is proven to work in your account. A
 * plain exported class with a constructor(state, env) and a fetch(request)
 * method — no imports, no extends.
 *
 * How it works
 * ------------
 * The app calls  POST /verify  with a password. If the password matches the
 * current (or previous) rotating window, the worker records the caller's IP
 * as a trusted address and returns a token. The app caches that token
 * locally, so the password is only ever asked ONCE per device.
 *
 * The password is *generated* from a secret seed + a time window, so it
 * rotates automatically every ROTATE_DAYS (default 2, range 1-3). You never
 * edit a password file — you open the admin page to read the current
 * password and hand it out to new users. Already-trusted users stay unlocked.
 *
 * Setup
 * -----
 *   1. dash.cloudflare.com -> Workers & Pages -> Create -> Create Worker.
 *   2. Open the worker -> Edit code -> replace the default code with THIS
 *      file's contents -> Deploy.
 *   3. Settings -> Durable Objects -> Add binding:
 *          Binding name:  ACCESS      (must match env.ACCESS in the code)
 *          Class name:    AccessVault (must match export class AccessVault)
 *      Then Deploy again. (This is the step that creates the Durable Object.)
 *   4. Settings -> Variables and Secrets -> add ADMIN_KEY and SEED, then
 *      Deploy. These override the fallbacks at the top of this file.
 *   5. Your URL is:  https://<worker-name>.<your-subdomain>.workers.dev
 *      Put that URL (obfuscated) into CORE_FILES/access.py.
 *
 * API
 * ---
 *   GET  /                          setup self-test page (binding / crypto /
 *                                   password-generation / storage checks)
 *   GET  /status                    health check JSON
 *   GET  /crypto-test               JSON crypto probe
 *   POST /verify                    body: {"password": "<current password>"}
 *       -> {"ok": true, "token": "...", "ip": "1.2.3.4"}   (success)
 *       -> {"ok": false, "error": "Incorrect password."}   (wrong password)
 *   GET  /admin?key=<ADMIN_KEY>     HTML page: current + next password,
 *                                   rotation window, and every trusted IP.
 *   GET  /passwords?key=<ADMIN_KEY> JSON: current/next/previous password,
 *                                   timestamps, and trusted IPs.
 */

// Fallback secrets. For production, set ADMIN_KEY and SEED as Worker secrets
// (Settings -> Variables and Secrets) and leave these as harmless placeholders.
const FALLBACK_ADMIN_KEY = "CHANGE-ME-admin-key";
const FALLBACK_SEED = "CHANGE-ME-seed";

// How often the password changes. 1..3 days (default 2).
const ROTATE_DAYS = 2;

async function passwordForWindow(seed, windowNum) {
  const data = new TextEncoder().encode(`${seed}|window|${windowNum}`);
  const digest = await crypto.subtle.digest("SHA-256", data);
  const bytes = new Uint8Array(digest);
  let hex = "";
  // 6 bytes -> 12 hex chars (48 bits). Enough for a sharing password.
  for (let i = 0; i < 6; i++) {
    hex += bytes[i].toString(16).padStart(2, "0");
  }
  return hex.toUpperCase();
}

export default {
  async fetch(request, env) {
    const url = new URL(request.url);

    // Self-test page — shows pass/fail for each piece of the setup.
    if (request.method === "GET" && url.pathname === "/") {
      return renderSelfTest(await runSelfTest(env));
    }

    if (request.method === "GET" && url.pathname === "/status") {
      return json({
        ok: true,
        service: "Systematics access worker (Cloudflare)",
        binding: !!env.ACCESS,
      });
    }

    if (request.method === "GET" && url.pathname === "/crypto-test") {
      try {
        const pw = await passwordForWindow((env.SEED || FALLBACK_SEED), 0);
        return json({ ok: true, generated: typeof pw === "string" && pw.length === 12 });
      } catch (err) {
        return json({ ok: false, error: "crypto failed: " + ((err && err.message) || String(err)) }, 500);
      }
    }

    if (!env.ACCESS) {
      return json({
        error: "Missing ACCESS Durable Object binding. Add one in Settings -> "
             + "Durable Objects (binding name: ACCESS, class: AccessVault).",
      }, 500);
    }

    // Everything else is served by the single global vault instance.
    try {
      const stub = env.ACCESS.get(env.ACCESS.idFromName("vault"));
      return await stub.fetch(request);
    } catch (err) {
      return json({ error: "do error: " + ((err && err.message) || String(err)) }, 500);
    }
  },
};

/**
 * Single global Durable Object: stores trusted IPs and answers every request.
 * Durable Objects run one request at a time, so the read-modify-write of the
 * trusted-IP map below can never lose an entry.
 */
export class AccessVault {
  constructor(state, env) {
    this.storage = state.storage;
    this.env = env;
  }

  get adminKey() {
    return (this.env && this.env.ADMIN_KEY) || FALLBACK_ADMIN_KEY;
  }

  get seed() {
    return (this.env && this.env.SEED) || FALLBACK_SEED;
  }

  async fetch(request) {
    try {
      const url = new URL(request.url);

      if (request.method === "GET" && url.pathname === "/health") {
        // Prove this instance can be created AND its storage can read/write.
        await this.storage.put("__probe", { t: Date.now() });
        const probe = await this.storage.get("__probe");
        return json({ ok: true, storage: !!probe });
      }

      if (request.method === "POST" && url.pathname === "/verify") {
        return this.verify(request);
      }

      if (request.method === "GET" && url.pathname === "/admin") {
        return this.adminPage(url);
      }

      if (request.method === "GET" && url.pathname === "/passwords") {
        return this.passwordsJson(url);
      }

      return json({ error: "not found" }, 404);
    } catch (err) {
      return json({ error: "vault error: " + ((err && err.message) || String(err)) }, 500);
    }
  }

  // ---- password generation ------------------------------------------------

  async passwordForWindow(windowNum) {
    return passwordForWindow(this.seed, windowNum);
  }

  async passwords() {
    const now = Date.now();
    const windowNum = Math.floor(now / (ROTATE_DAYS * 86400000));
    const current = await this.passwordForWindow(windowNum);
    const previous = await this.passwordForWindow(windowNum - 1);
    const next = await this.passwordForWindow(windowNum + 1);
    const currentUntil = (windowNum + 1) * ROTATE_DAYS * 86400000;
    const nextUntil = (windowNum + 2) * ROTATE_DAYS * 86400000;
    return { current, previous, next, windowNum, currentUntil, nextUntil };
  }

  // ---- /verify ------------------------------------------------------------

  async verify(request) {
    const body = await request.json().catch(() => null);
    const password = String((body && body.password) || "").trim();
    if (!password) {
      return json({ ok: false, error: "Missing password." }, 400);
    }

    const { current, previous } = await this.passwords();
    if (password !== current && password !== previous) {
      return json({ ok: false, error: "Incorrect password." });
    }

    const ip = request.headers.get("CF-Connecting-IP")
      || request.headers.get("X-Forwarded-For")
      || "unknown";

    const token = crypto.randomUUID();
    await this.record(ip);
    await this.storage.put("token:" + token, { ip, granted_at: Date.now() });

    return json({ ok: true, token, ip });
  }

  async record(ip) {
    const trusted = (await this.storage.get("trusted")) || {};
    trusted[ip] = { granted_at: Date.now() };
    await this.storage.put("trusted", trusted);
  }

  async trustedList() {
    return (await this.storage.get("trusted")) || {};
  }

  // ---- admin --------------------------------------------------------------

  authorized(url) {
    return (url.searchParams.get("key") || "") === this.adminKey;
  }

  async passwordsJson(url) {
    if (!this.authorized(url)) {
      return json({ error: "unauthorized" }, 401);
    }
    const p = await this.passwords();
    const trusted = await this.trustedList();
    return json({
      rotate_days: ROTATE_DAYS,
      current: p.current,
      current_until: p.currentUntil,
      previous: p.previous,
      next: p.next,
      next_until: p.nextUntil,
      trusted_ips: Object.keys(trusted).sort(),
      trusted_count: Object.keys(trusted).length,
    });
  }

  async adminPage(url) {
    if (!this.authorized(url)) {
      return json({ error: "unauthorized" }, 401);
    }
    const p = await this.passwords();
    const trusted = await this.trustedList();
    const ips = Object.keys(trusted).sort();

    const rows = ips.length
      ? ips.map((ip) => {
          const t = new Date((trusted[ip] && trusted[ip].granted_at) || 0).toISOString();
          return `<tr><td>${escapeHtml(ip)}</td><td>${escapeHtml(t)}</td></tr>`;
        }).join("")
      : "<tr><td colspan='2'>No trusted devices yet.</td></tr>";

    const html = `<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Systematics TRILLION MIDI maker — access admin</title>
<style>
  body { font-family: system-ui, Segoe UI, sans-serif; background:#121212; color:#eee; margin:0; padding:32px; }
  .card { background:#1e1e1e; border:1px solid #333; border-radius:10px; padding:20px 24px; max-width:720px; margin:0 auto; }
  h1 { font-size:18px; margin:0 0 4px; }
  .sub { color:#9aa; margin:0 0 20px; font-size:13px; }
  .pw { font-family: Consolas, monospace; font-size:34px; letter-spacing:3px; color:#4fc3f7; margin:6px 0 2px; }
  .label { color:#9aa; font-size:12px; text-transform:uppercase; letter-spacing:1px; }
  .box { background:#181818; border:1px solid #2a2a2a; border-radius:8px; padding:12px 16px; margin:14px 0; }
  table { width:100%; border-collapse:collapse; font-size:13px; }
  td { padding:6px 8px; border-bottom:1px solid #2a2a2a; }
  th { text-align:left; color:#9aa; font-weight:600; padding:6px 8px; border-bottom:1px solid #2a2a2a; }
</style>
</head>
<body>
  <div class="card">
    <h1>Access admin</h1>
    <p class="sub">Give the CURRENT password to new users. It rotates every ${ROTATE_DAYS} day(s).</p>

    <div class="box">
      <div class="label">Current password (until ${new Date(p.currentUntil).toUTCString()})</div>
      <div class="pw">${escapeHtml(p.current)}</div>
    </div>

    <div class="box">
      <div class="label">Next password (from ${new Date(p.currentUntil).toUTCString()} to ${new Date(p.nextUntil).toUTCString()})</div>
      <div class="pw" style="color:#81c784">${escapeHtml(p.next)}</div>
    </div>

    <div class="box">
      <div class="label">Trusted devices (${ips.length})</div>
      <table>
        <tr><th>IP address</th><th>Unlocked at (UTC)</th></tr>
        ${rows}
      </table>
    </div>
  </div>
</body>
</html>`;

    return new Response(html, {
      status: 200,
      headers: { "Content-Type": "text/html; charset=utf-8" },
    });
  }
}

// ---------------------------------------------------------------------------
// Self-test
// ---------------------------------------------------------------------------

async function runSelfTest(env) {
  const checks = [];

  // 1. Binding present.
  checks.push(env.ACCESS
    ? { name: "ACCESS Durable Object binding", ok: true, detail: "Binding is present." }
    : { name: "ACCESS Durable Object binding", ok: false, detail: "env.ACCESS is undefined. Add a Durable Object binding named ACCESS (class AccessVault)." });

  // 2. Crypto.
  try {
    const data = new TextEncoder().encode("self-test");
    const digest = await crypto.subtle.digest("SHA-256", data);
    checks.push({ name: "Crypto (SHA-256)", ok: !!digest, detail: "crypto.subtle.digest worked." });
  } catch (err) {
    checks.push({ name: "Crypto (SHA-256)", ok: false, detail: String((err && err.message) || err) });
  }

  // 3. Password generation.
  try {
    const seed = (env && env.SEED) || FALLBACK_SEED;
    const windowNum = Math.floor(Date.now() / (ROTATE_DAYS * 86400000));
    const pw = await passwordForWindow(seed, windowNum);
    checks.push({ name: "Password generation", ok: /^[0-9A-F]{12}$/.test(pw), detail: "Generated a 12-char password (value hidden for security)." });
  } catch (err) {
    checks.push({ name: "Password generation", ok: false, detail: String((err && err.message) || err) });
  }

  // 4. Durable Object can be created and its storage can read/write.
  if (!env.ACCESS) {
    checks.push({ name: "Durable Object (AccessVault)", ok: false, detail: "Skipped — no ACCESS binding." });
  } else {
    try {
      const stub = env.ACCESS.get(env.ACCESS.idFromName("vault"));
      const resp = await stub.fetch(new Request("https://access-vault.internal/health"));
      if (resp.status === 200) {
        const body = await resp.json().catch(() => null);
        if (body && body.ok && body.storage) {
          checks.push({ name: "Durable Object (AccessVault)", ok: true, detail: "Instance created and storage read/write worked." });
        } else {
          checks.push({ name: "Durable Object (AccessVault)", ok: false, detail: "Responded but storage probe failed: " + JSON.stringify(body) });
        }
      } else {
        checks.push({ name: "Durable Object (AccessVault)", ok: false, detail: "Returned HTTP " + resp.status });
      }
    } catch (err) {
      checks.push({ name: "Durable Object (AccessVault)", ok: false, detail: String((err && err.message) || err) });
    }
  }

  return checks;
}

function renderSelfTest(checks) {
  const rows = checks.map((c) => {
    const badge = c.ok ? "PASS" : "FAIL";
    const color = c.ok ? "#4caf50" : "#e5484d";
    return `<tr><td>${escapeHtml(c.name)}</td><td><span style="color:${color};font-weight:700">${badge}</span></td><td>${escapeHtml(c.detail)}</td></tr>`;
  }).join("");

  const allOk = checks.every((c) => c.ok);

  const html = `<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Access setup self-test</title>
<style>
  body { font-family: system-ui, Segoe UI, sans-serif; background:#121212; color:#eee; margin:0; padding:32px; }
  .card { background:#1e1e1e; border:1px solid #333; border-radius:10px; padding:20px 24px; max-width:760px; margin:0 auto; }
  h1 { font-size:18px; margin:0 0 4px; }
  .sub { color:#9aa; margin:0 0 20px; font-size:13px; }
  table { width:100%; border-collapse:collapse; font-size:13px; }
  td { padding:8px; border-bottom:1px solid #2a2a2a; vertical-align:top; }
  th { text-align:left; color:#9aa; font-weight:600; padding:8px; border-bottom:1px solid #2a2a2a; }
  .verdict { font-size:16px; font-weight:700; margin-top:16px; }
</style>
</head>
<body>
  <div class="card">
    <h1>Access setup self-test</h1>
    <p class="sub">Checks the pieces this password gate needs. All must PASS for the app to work.</p>
    <table>
      <tr><th>Check</th><th>Result</th><th>Detail</th></tr>
      ${rows}
    </table>
    <div class="verdict" style="color:${allOk ? "#4caf50" : "#e5484d"}">
      ${allOk ? "ALL CHECKS PASSED" : "SOME CHECKS FAILED — see details above."}
    </div>
  </div>
</body>
</html>`;

  return new Response(html, {
    status: 200,
    headers: { "Content-Type": "text/html; charset=utf-8" },
  });
}

function escapeHtml(s) {
  return String(s)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

function json(data, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: {
      "Content-Type": "application/json",
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
      "Access-Control-Allow-Headers": "Content-Type",
    },
  });
}
